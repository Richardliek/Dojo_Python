class Ninja:
    def __init__(self, first_name, last_name, treats, pet_food, pet)
        self.first_name = first_name
        self. = 
        self.first_name = first_name
        self.first_name = first_name
        