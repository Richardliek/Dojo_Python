class Book:
    def __init__(self,title,pages,chapters,text):
        self.title = title
        self.pages = pages
        self.chapters = chapters
        self.text = text
        self.current_page = 0

    def read_book(self, ending_page):
        self.current_page = ending_page
        return self

class Textbook(Book): # Inheriting from the Book class
    def __init__(self,title,pages,chapters,text, pictures=[]):
        super().__init__(title,pages,chapters,text) # Call on the init method in the Book class
        self.pictures = pictures
        self.index_length = 0 # Number of pages in the index - 0 by default

    def read_book(self, ending_page): # Different read_book method from the Book class - example of polymorphism
        # If ending page is past the last readable page
        if ending_page > self.pages - self.index_length:
            self.current_page = self.pages - self.index_length
        else:
            self.current_page = ending_page
        return self

    # Method to add an index to the textbook - new to this class; doesn't exist in Book class
    def add_index(self, length):
        self.index_length = length
        self.pages += length # Add this to the total number of pages in the book itself
        return self

some_book = Book("Harry Potter and the Chamber of Secrets",330,25,"....")
some_book.read_book(50).read_book(120)
print(some_book.current_page)

math_book = Textbook("Intro to Calculus",1200,15,"...")
math_book.read_book(100)
print(math_book.current_page)