# Introduction to Object-Oriented Programming (OOP)

Every day in our lives, we interact with people, computers, books, and anything you can describe by a noun (person, place, thing or idea).  For example, you interact with a microwave, an oven or stove, a toaster, etc. to warm or bake food.  We can describe an oven in a bunch of ways - its brand name, max temperature, number of ovens (some come with two!), etc.  The same with a book - number of pages, its title, the text itself, its author, etc.

## Defining objects
Here is how we can define an object in Python:
```py
class ClassName: # Parentheses optional if not inheriting (see Wednesday's lecture)
    def __init__(self):
        self.attribute_name = value
```
By convention, the name of your class should be Pascal Case, so each word is capitalized.  The init method is called whenever we create an **instance** of a class, in other words, creating an individual copy of the class.  Inside the init method we have **attributes**, which describe the properties of the class.  You can pass as many values as you want as parameters for the init method, and you can define as many attributes as you want.  Here is an example with a book:
```py
class Book:
    def __init__(self, title, author, page_count):
        self.title = title
        self.author = author
        self.number_of_pages = page_count
        # You can also add attributes and give them default values:
        self.pages_read = 0
```
We have defined a Book class that has four attributes: title, author, number of pages and pages read.  Here's how to create instances of books:
```py
gatsby = Book("The Great Gatsby", "F. Scott Fitzgerald", 250)
eyre = Book("Jane Eyre", "Charlotte Bronte", 400)
```

We can print an attribute if we wanted:
```py
print(gatsby.title) # "The Great Gatsby"
print(eyre.author) # "Charlotte Bronte"
```

### Note about "self"
The word **self** is referring to an individual instance of a class.  So when we created the gatsby variable, the init method is basically giving the gatsby variable an instance of the Book class, and it has a title called "The Great Gatsby".  So think of "self.title" in this case as "gatsby.title", where "self" is referring to the variable in question that is holding an instance of the Book class.

The world "self" per se (by itself) holds an entire instance of the class.  Read on to see more uses of "self".

## Instance methods
We can have the classes do stuff, like have an oven bake a cake, or read a book to a certain point, or have a person interact with another person.  Let's demonstrate with a couple of methods for our book class:
```py
class Book:
    def __init__(self, title, author, page_count):
        self.title = title
        self.author = author
        self.number_of_pages = page_count
        self.pages_read = 0

    # Below are two instance methods - note the word self as the first parameter in each!
    def read_book(self, ending_point):
        self.pages_read = min(ending_point, self.number_of_pages) # Return the smaller of these values as you cannot read past the final page
    
    def is_finished(self):
        if self.pages_read == self.number_of_pages:
            print("Book is finished")
        else:
            print("Book is not fully read")
```
We have defined two **instance methods**, which are methods that are tied to an individual instance of a class.  In this case, we have defined two methods called "read_book" and "is_finished", which allows a person to read the book to a certain point, and checks to see if the book has been read completely, respectively.  Notice in both methods we are using the word "self", which holds an individual instance of the Book class.  Here is a demonstration:

```py
gatsby.read_book(50) # Read first 50 pages
gatsby.read_book(120) # Read 70 more pages
gatsby.is_finished() # False - not done yet
gatsby.read_book(250) # Read remaining pages
gatsby.is_finished() # True - now done
```

## Chaining commands
Imagine doing this in real life while facing the same person the entire time: "Adrian, wash the dishes.  Adrian, pick up the mail.  Adrian, cook dinner."  You don't need to refer to the same person 3 times in the conversation when you're facing them.  You saw how we're calling on the `gatsby` variable several times in a row.  Well, we have a way to simplify this - and this is through **chaining**.  Chaining allows us to type several commands in a row while referring to the same variable.

To accomplish this, **every** instance method other than "init" must have `return self`.  Here is an example using the same Book class, with two methods changed:
```py
    # Below are two instance methods - note the word self as the first parameter in each!
    def read_book(self, ending_point):
        self.pages_read = min(ending_point, self.number_of_pages) # Return the smaller of these values as you cannot read past 
        return self
    
    def is_finished(self):
        if self.pages_read == self.number_of_pages:
            print("Book is finished")
        else:
            print("Book is not fully read")
        return self
```
Now we can do this in one line through chaining:
```py
gatsby.read_book(50).read_book(120).is_finished().read_book(250).is_finished()
```
So chaining is done by doing:
```py
variable_name.method_name().method_name().method_name()
```
You can use any methods you want in any order or combination you wish, but remember to have `return self` for all of those methods, otherwise you'll get a error (likely NoneType since a method that doesn't have a return statement will have "None").

## Class methods and variables
So far we've gone over instance methods and attributes that define what an object can do and how it is described.  So think of it like verbs and nouns in English - a verb describes an action that can be performed, and a noun is used to define a person, place, thing (like an object) or idea.

But what if we want to define a quality or action that is to be used by the general class itself?  Let's demonstrate with an example from our Book class:
```py
class Book:
    number_of_books = 0 # This is a class variable
    library_name = "My Library" # And another one

    def __init__(self, title, author, page_count):
        self.title = title # This is an attribute for an *individual* book
        self.author = author
        self.number_of_pages = page_count
        self.pages_read = 0
        Book.number_of_books += 1 # Increment the total number of books - notice how we're accessing a class variable
    
    # Instance methods omitted for brevity

# Two ways to access
print(Book.number_of_books) # Recommended
print(eyre.number_of_books)
```
Here we have defined a **class variable**, which is a variable that is tied to the class and not to a single instance of said class.  It is defined outside of any methods; you should put them just after the definition of your class.

In this example, we made a class variable called `number_of_books`.  We increment it inside the init method.  You can access class variables inside instance methods by doing `ClassName.class_variable`.

You can also define class methods as well:
```py
class Book:
    # Only the class method shown for brevity
    @classmethod # Decorator - describes a function or method
    def rename_library(cls, new_name):
        cls.library_name = new_name # cls refers to the class itself you're in

Book.rename_library("The Miniature Library") # Rename the library
print(Book.library_name)
```
A **class method** is similar to an instance method, except with a class method you can access class variables.  Notice the `cls` as the first parameter - that holds all your class variables and class methods.  

IMPORTANT: You do NOT have access to instance methods or attributes - those that have "self" - from a class method.

We will be using class methods a ton when we start dealing with databases and Flask, so know how these work!

## Static methods
A **static** method is a method that has no access to class or instance methods or variables.  So one might naturally think, why would you have one?  Static methods are used to perform operations that don't involve a single instance of a class.  Maybe you want to perform a mathematical operation or some other type of check.  Here is an example:

```py
class Book:
    @staticmethod # Notice the decorator
    def pages_left(current_page_to_start, number_of_pages):
        return number_of_pages - current_page_to_start
``` 
This static method calculates the number of pages left to read if given a starting page number (current_page_to_start) and the number of pages in the book.

We will be using static methods to perform validations for handling data soon.

## Linking classes
In OOP objects interact a lot with one another.  Let's define another class to supplement the Book class:
```py
class Reader:
    def __init__(self, name, books = []):
        self.name = name
        self.books = books # A list of book objects

    # Read a book
    def read_book(self,index,page_number):
        self.books[index].read_book(page_number)
        return self

    # Add a Book (note the capitalization) to the list of books for this reader
    def add_book(self,new_book):
        self.books.append(new_book)
        return self

johnny = Reader("Johnny") # No second argument given (books), so we'll have an empty list of books for Johnny to start
new_book = Book("Canterbury Tales","Geoffrey Chaucer",1500) # Create an instance of a Book
johnny.add_book(new_book) # Add this book to Johnny's list
johnny.read_book(0,50) # Read to page 50 of "Canterbury Tales"
johnny.add_book(Book("The Old Man and the Sea","Ernest Hemingway",175))
johnny.read_book(1,30) # Read to page 30 of "The Old Man and the Sea"
johnny.read_book(0,120) # Read another 70 pages of "Canterbury Tales"
```

Here we have defined a reader and some books for him to read.  Notice that the books attribute is going to hold a list of Book instances - in this case, two books after the code is finished.  We can also chain commands here (not shown)!