# More on Object-Oriented Programming (OOP) - including the Four Pillars

Object-oriented programming (OOP) is used quite a bit in order to reduce redunancy, or repetition, in our code - so we can be more efficient.  You wouldn't want a ton of code repeated that accomplishes the same goal for different objects.  Our code should be as clean and concise as possible, and the **four pillars of object-oriented programming (OOP)** will help us accomplish that goal:

1. Encapsulation
2. Inheritance
3. Polymorphism
4. Abstraction

If these words sound absolutely foreign to you, do not panic - we'll break these down one at a time and give a practical perspective for each.

We'll also cover how to loop through a list of classes, which will be essential when we combine Flask and MySQL in a few weeks!

## Encapsulation

**Encapsulation** is the idea of grouping a bunch of methods and attributes together in an object.  So you've been practicing encapsulation all along without realizing it!  Here is a code snippet:

```py
class Book:
    def __init__(self, title, author, page_count):
        self.title = title
        self.author = author
        self.number_of_pages = page_count
        self.pages_read = 0

    # Below are two instance methods - note the word self as the first parameter in each!
    def read_book(self, ending_point):
        self.pages_read = min(ending_point, self.number_of_pages) # Return the smaller of these values as you cannot read past the final page
        return self
    
    def is_finished(self):
        if self.pages_read == self.number_of_pages:
            print("Book is finished")
        else:
            print("Book is not fully read")
        return self
```
When defining this Book, we're describing - or encapsulating - its qualities (attributes) and methods (actions or behaviors).  Think of encapsulation as the blueprints for an object.  So a Book has a title, author, number of total pages and number of pages read, while we can read it and check to see if we're done.  There's much more you can do with a Book, but I'll let you decide!

## Inheritance

Let's define a work of nonfiction:
```py
class Nonfiction:
    def __init__(self, title, author, genre, page_count, pictures = []):
        self.title = title
        self.author = author
        self.genre = genre # NEW
        self.number_of_pages = page_count
        self.pictures = pictures # NEW
        self.pages_read = 0

    # Below are two instance methods - note the word self as the first parameter in each!
    def read_book(self, ending_point):
        self.pages_read = min(ending_point, self.number_of_pages) # Return the smaller of these values as you cannot read past the final page
        return self
    
    def is_finished(self):
        if self.pages_read == self.number_of_pages:
            print("Book is finished")
        else:
            print("Book is not fully read")
        return self

    def add_picture(self,new_picture): # NEW
        self.pictures.append(new_picture)
        return self
```
We have added two new attributes - genre and pictures - and created a method to add a picture to the book.  Notice how a lot of the methods are the same or very similar?

This is where **inheritance** comes in, where you can just grab the same methods and attributes from a different class.  Let's demonstrate:
```py
class Nonfiction(Book): # We now inherit from the Book class
    def __init__(self, title, author, genre, page_count, pictures = []):
        super().__init__(title, author, page_count) # Call on the Book's init method to add attributes named title, author, number_of_pages and pages_read
        self.genre = genre # NEW attribute
        self.pictures = pictures # NEW attribute

    # Don't need to redefine read_book or is_finished - we'll use Book's read_book and is_finished methods

    def add_picture(self,new_picture): # NEW
        self.pictures.append(new_picture)
        return self
```
Notice how much shorter this code is?  The Nonfiction class will have a new method called `add_picture`, and it'll utilize Book's `read_book` and `is_finished` methods and the attributes named `title`, `author`, `number_of_pages` and `pages_read`.  Notice that none of these are defined here in the Nonfiction class; the methods are inherited when we grab from the Book class, and the attributes are set by calling on the superclass's init method.  A *superclass* is a class that's being inherited, so the superclass of Nonfiction is Book in this case.

## Polymorphism

**Polymorphism** means taking on many shapes or forms.  In the context of OOP, that means the same methods can do different things for different classes.  Here is an example:

```py
class Nonfiction(Book): # We now inherit from the Book class
    def __init__(self, title, author, genre, page_count, pictures = []):
        super().__init__(title, author, page_count) # Call on the Book's init method to add attributes named title, author, number_of_pages and pages_read
        self.genre = genre
        self.pictures = pictures
        self.index_length = 0 # Added attribute

    # We're REDEFINING this method to account for the index at the end of the book
    def is_finished(self):
        if self.pages_read == self.number_of_pages - self.index_length:
            print("Book is finished")
        else:
            print("Book is not fully read")
        return self

    def add_picture(self,new_picture):
        self.pictures.append(new_picture)
        return self

    # NEW METHOD: Add an index to the end of the book
    def add_index(self,num_pages):
        self.index_length = num_pages
        self.number_of_pages += num_pages # Lengthen book due to index
        return self
```
Notice that there's a method called `is_finished` here, but the if condition is now different because we've added an index to the book, so we have to account for that.  So we are **overriding** the parent class (Book)'s `is_finished` method and using a new version for the Nonfiction class.  This is the idea of polymorphism - the function `is_finished` has different code in both the Book and Nonfiction classes.

## Abstraction
**Abstraction** is the idea that when a class interacts with another, we don't need to know all the gory details.  As a real-life example, imagine going to a deli to grab meat.  You don't need to know how the meat is made necessarily - all you want to do is order the meat and leave.  It's the same idea here in OOP - when you call on a method from a different class, you expect actions to be performed and then you will do something with the result afterwards.  So you could do something like this:

```py
class Human:
    def __init__(self, name):
        self.name = name
        self.dirty_clothes = []
        self.clean_clothes = []
        self.washer = WashingMachine("Amana")

    def do_laundry(self):
        self.washer.clean_clothes(self.dirty_clothes,self.clean_clothes)
        return self

    def add_clean_item(self, article):
        self.clean_clothes.append(article)
        return self

    def add_dirty_item(self, article):
        self.dirty_clothes.append(article)
        return self

    def show_clean_wardrobe(self):
        print("Clean clothes:")
        for item in self.clean_clothes:
            print(f"{item.color} {item.type}")
        return self

    def show_dirty_wardrobe(self):
        print("Dirty clothes:")
        for item in self.dirty_clothes:
            print(f"{item.color} {item.type}")
        return self
    
class Clothing:
    def __init__(self, clothing_type, color):
        self.type = clothing_type # Examples: shirt, shorts, pants, skirts, dresses, socks
        self.color = color

class WashingMachine:
    def __init__(self, brand_name):
        self.brand_name = brand_name

    def clean_clothes(self,dirty_basket,clean_basket):
        for item in dirty_basket:
            clean_basket.append(item) # Add item to list of clean clothes
        dirty_basket.clear() # Remove item from list of dirty clothes after cleaning everything
        return self

red_shirt = Clothing("shirt","red")
blue_shorts = Clothing("shorts","blue")

alex = Human("Alex")
alex.add_dirty_item(red_shirt).add_dirty_item(blue_shorts)
alex.show_dirty_wardrobe()
alex.do_laundry().show_clean_wardrobe()
```
Here a person named Alex will wash some clothes.  By calling on the clean_clothes() method for the WashingMachine class, it'll clean Alex's clothes.  (Not shown - adding detergent and possibly other stuff to facilitate the cleaning.)  You don't need to know all the intricacies of how the washing machine operates in order to clean your clothes.  This is the idea of abstraction - you approach an object and interact, expecting some result to come back; you don't need to know how the results came to be.

## Building instances of classes through dictionaries

We will be interacting with databases later in the course.  When we do, we will be grabbing a list of dictionaries from the database.  Here we will talk about how to create instances of classes from this list of dictionaries.  Let's demonstrate with an example:

```py
class Author:
    def __init__(self, data): # data is a dictionary
        self.id = data['id']
        self.name = data['name']
        self.year_of_birth = data['year_of_birth']

authors_list = [
    {
        'id': 1,
        'name': 'Louisa May Alcott',
        'year_of_birth': 1832
    },
    {
        'id': 2,
        'name': 'Mark Twain',
        'year_of_birth': 1835
    },
]

instances_of_authors = [] # List that will hold instances of the Author class
for this_author in authors_list: # Loop through each dictionary in the list
    author_instance = Author(this_author) # Create an instance of Author class
    instances_of_authors.append(author_instance) # Add this instance to new list called "instances_of_authors"
```
Here we are taking a list of authors in the variable called `authors_list` and then creating a new list called `instances_of_authors` that will hold instances of the Author class.  The for loop goes through each dictionary, and then creates an instance of the class, which is then added to `instances_of_authors`.

If you can understand this process, you'll be much better off in a few weeks.  We will be eventually using class methods to transform the data from the database into instances of classes - so stay tuned!

## Loop through a list of classes
Let's create a list of books:
```py
book_list = [
    Book("Pride and Prejudice", "Jane Austen", 300),
    Book("To Kill a Mockingbird", "Harper Lee", 250),
    Book("The Da Vinci Code", "Dan Brown", 400),
    Book("Harry Potter and the Goblet of Fire", "J. K. Rowling", 750)
]
for book in book_list:
    print(book.title)
```
You'll likely use a for loop to go through the list, where each item in the list is an instance of the class, in this case, the Book class.  So the variable "book" between the words `for` and `in` in the definition of the for loop will hold an instance of the Book class, giving you access to all its attributes (e.g. title, author) and methods (e.g. read_book).  Eventually in your HTML files you will be looping through a list of classes *a ton*, so definitely understand this!