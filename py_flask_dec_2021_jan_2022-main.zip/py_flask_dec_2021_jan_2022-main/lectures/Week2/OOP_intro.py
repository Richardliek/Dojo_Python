
class Genre: # Define a genre of music, e.g. rock, pop, rap
    def __init__(self, name): # Method used to create an instance of this class
        self.name = name # Attributes named name and artists
        self.artists = [] # Empty list that will hold instances of Artists (note the capitalization)
        # Name of genre, artists, BPM, decades
    
    # Instance method - notice the "self" as the first parameter
    def add_artist(self, new_artist):
        self.artists.append(new_artist) # new_artist is an instance of the Artist class
        return self # Allows for chaining

class Artist:
    number_of_artists = 0 # Class variable
    all_artists = [] # Class variable that will hold instances of the Artist class

    def __init__(self, name, origin, age):
        self.name = name
        self.starting_point = origin
        self.age = age
        self.songs = []
        Artist.number_of_artists += 1 # To access a class variable from an instance method, you type
        # ClassName.class_variable
        Artist.all_artists.append(self) # Adding an instance of the Artist class to the list

    # Instance method
    def add_song(self, new_song):
        self.songs.append(new_song) # new_song is an instance of the Song class
        return self # Allows for chaining
    
    # Method to show the names of all the artists
    @classmethod
    def show_all_artists(cls):
        for artist in cls.all_artists: # To access a class variable in a class method, do cls.class_variable
            print(artist.name)
    # Name, songs, where they started (or born), age

class Song:
    def __init__(self, title, length, lyrics):
        self.title = title
        self.length_of_time = length # In seconds
        self.lyrics = lyrics
        # Title, length of song, lyrics, artist, instruments

    def change_lyrics(self, new_lyrics):
        self.lyrics = new_lyrics
        return self

    def change_time(self,new_time):
        self.length_of_time = new_time
        return self

    @staticmethod
    def is_song_long_enough(seconds):
        if seconds > 90:
            return True
        else:
            return False

# Create instances of these classes
rock = Genre("Rock")
bon_jovi = Artist("Bon Jovi", "New Jersey", 59)
dead_or_alive = Song("Dead or Alive",300,"I'm wanted...")
living_on_a_prayer = Song("Living on a Prayer",240,"Ready or not...")
bon_jovi.add_song(dead_or_alive).add_song(living_on_a_prayer) # Link songs to Bon Jovi
rock.artists.append(bon_jovi) # Lin Bon Jovi to the rock genre

glenn_frey = Artist("Glenn Frey", "Arizona", 75)
elvis_presley = Artist("Elvis Presley","Mississippi",86)
john_lennon = Artist("John Lennon", "Liverpool", 81)

# Define Songs and link them to Elvis Presley
heartbreak_hotel = Song("Heartbreak Hotel",150,"Well since my...")
suspicious_minds = Song("Suspicious Minds",270,"We can't go on together...")
elvis_presley.add_song(heartbreak_hotel).add_song(suspicious_minds)

# Link artists to rock genre
rock.add_artist(glenn_frey).add_artist(elvis_presley).add_artist(john_lennon)

# IMPORTANT: Looping through a list of classes - we'll do this a lot later on!

# Loop through an artist's songs
for song in elvis_presley.songs:
    print(song.title)

# Loop through all the rock artists - one way to do it
for artist in rock.artists:
    print(f"{artist.name}'s songs:")
    for song in artist.songs: # Loop through all the songs for this artist
        print(song.title)

paul_mccartney = Artist("Paul McCartney", "Liverpool", 78)

print(Artist.number_of_artists)

Artist.show_all_artists() # To access a class method, type ClassName.class_method()

new_song_length = 180
print(Song.is_song_long_enough(new_song_length))

""" 
IMPORTANT: Creating instances of classes through a list of dictionaries
"""

class NewArtist:
    def __init__(self, data): # Data is going to be a dictionary
        self.id = data['id']
        self.name = data['name']
        self.starting_point = data['starting_point']
        self.age = data['age']

artist_data = [
    {
        "id":1,
        "name":"Jon Bon Jovi",
        "starting_point": "England",
        "age": 59,
    },
    {
        "id": 2,
        "name": "Adele",
        "starting_point": "Britain",
        "age": 33,
    },
]

artist_instances = [] # List of instances of the NewArtist class
for this_artist in artist_data: # Loop through the list of dictionaries
    new_artist_instance = NewArtist(this_artist)
    artist_instances.append(new_artist_instance)

for current_artist in artist_instances: # Loop through the list of classes
    print(current_artist.name)

# print(artist_instances)