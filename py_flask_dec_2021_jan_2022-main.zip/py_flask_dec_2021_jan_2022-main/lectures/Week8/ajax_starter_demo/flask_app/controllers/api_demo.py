from flask_app import app # NEED this line for app.route() among other things
from flask import render_template
import requests, os # New package installed into our environment: requests

@app.route("/api_demo")
def api_demo():
    # Link I used: https://api.nasa.gov/
    r = requests.get(f"https://api.nasa.gov/planetary/apod?api_key={os.environ.get('NASA_API_KEY')}&date=2022-01-31")
    image_info = r.json() # Convert response to JSON
    print(image_info)
    return render_template("api_demo.html", image_link = image_info["url"])