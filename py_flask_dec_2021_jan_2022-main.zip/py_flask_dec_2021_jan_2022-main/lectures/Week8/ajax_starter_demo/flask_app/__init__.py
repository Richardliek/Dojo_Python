from flask import Flask
import os # For loading values from .env files
app = Flask(__name__) # Creates instance of Flask class here
# print(os.environ.get("FLASK_SECRET_KEY"))
app.secret_key = os.environ.get("FLASK_SECRET_KEY") # Secret key goes here