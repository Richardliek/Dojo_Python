const grabAllTeams = () => { // let const "var"
    console.log("This button was clicked");
    fetch("http://localhost:5000/grab_all_teams", { method: "GET" })
        .then( response => response.json() )
        .then( data => {
            // console.log(data);
            let str1 = `Hello
            World
            Again
            !`;
            // console.log(str1);
            let placeholder_div = document.getElementById("ajax_data_placeholder");
            // Reset the div
            placeholder_div.innerHTML = "";
            /* Create a table */
            // Creating the head of table
            let new_table = document.createElement("table");
            let table_head = document.createElement("thead");
            let inner_table_head_HTML = `<tr>
            <th>ID</th>
            <th>Team name</th>
            </tr>`;
            console.log(inner_table_head_HTML)
            table_head.innerHTML = inner_table_head_HTML;
            new_table.appendChild(table_head);
            // Create the body of the table
            let table_body = document.createElement("tbody");
            for (let k = 0; k < data.length; k++) {
                let new_row = document.createElement("tr");
                new_row.innerHTML += "<td>";
                new_row.innerHTML += data[k]["id"];
                new_row.innerHTML += "</td>";
                new_row.innerHTML += "<td>";
                new_row.innerHTML += data[k]["city"] + " " + data[k]["name"];
                new_row.innerHTML += "</td>";
                table_body.appendChild(new_row);
            }
            new_table.appendChild(table_body);
            placeholder_div.appendChild(new_table);
        })
}


function grabOneTeam(event) {
    event.preventDefault();
    var searchForm = document.getElementById('find_team');
    var form = new FormData(searchForm);
    fetch('http://localhost:5000/get_one_team_ajax',{method:'POST',body:form})
        .then(res => res.json() )
        .then( data => {
            // Clear the div out
            let placeholder_div = document.getElementById("ajax_data_placeholder");
            placeholder_div.innerHTML = "";
            let team_info = `
            <h1>${data['city']} ${data['name']}</h1>
            <p>Team #${data['id']}</p>
            <p>Stadium name: ${data['stadium_name']}</p>
            `;
            placeholder_div.innerHTML = team_info;
            let edit_delete_buttons = `
            <a class="btn btn-warning mx-2" onclick="editTeamPage()" role="button">
            Edit ${data['city']} ${data['name']}
            </a> 
            <a class="btn btn-danger mx-2" onclick="deleteTeam()" role="button">
            Delete ${data['city']} ${data['name']}
            </a> 
            `
            placeholder_div.innerHTML += edit_delete_buttons;

        } )
}

function deleteTeam() {
    fetch("http://localhost:5000/delete_team_ajax", { method: "DELETE" }) // This is a DELETE, not a POST or GET request
        .then( response => response.json() )
        .then( data => {
            // Clear the div out
            let placeholder_div = document.getElementById("ajax_data_placeholder");
            placeholder_div.innerHTML = "";
            // Reset the dropdown menu
            let teams_div = document.getElementById("listed_teams");
            teams_div.innerHTML = "";
            new_team_HTML_string = '<select name="team_id">';
            for (let k = 0; k < data.length; k++) {
                new_team_HTML_string += `<option value="${data[k]['id']}">${data[k]['city']} ${data[k]['name']}</option>`;
            }
            new_team_HTML_string += "</select>";
            new_team_HTML_string += `<input type="submit" value="Select team">`; // Need this so you can submit
            teams_div.innerHTML = new_team_HTML_string;
        })
}

function editTeamPage() {
    fetch("http://localhost:5000/grab_team_to_view_or_edit", { method: "GET"})
        .then( response => response.json() )
        .then( data => {
            // Clear the div out
            let placeholder_div = document.getElementById("ajax_data_placeholder");
            placeholder_div.innerHTML = "";
            // Build out edit form
            new_team_form_HTML = `
            <form id="team_edit_form" onsubmit="editTeamInDB(event)">
                <h3>Edit ${data['city']} ${data['name']}</h3>
                <div class="row my-4">
                    <label for="city" class="col-12 col-md-3 fs-4 col-form-label">City:</label>
                    <input type="text" name="city" class="col-12 col-md-9 col-form-control" id="city" value="${data['city']}" placeholder="Type in city">
                </div>
                <div class="row my-4">
                    <label for="nickname" class="col-12 col-md-3 fs-4 col-form-label">Nickname:</label>
                    <input type="text" name="nickname" class="col-12 col-md-9 col-form-control" id="nickname" value="${data['name']}">
                </div>
                <div class="row my-4">
                    <label for="stadium_name" class="col-12 col-md-3 fs-4 col-form-label">Stadium name:</label>
                    <input type="text" name="stadium_name" class="col-12 col-md-9 col-form-control" id="stadium_name" value="${data['stadium_name']}">
                </div>
                <div class="row justify-content-center">
                    <input type="submit" class="col-12 col-md-2 fs-4 btn btn-primary" value="Edit team">
                </div>
            </form>`;
            placeholder_div.innerHTML = new_team_form_HTML;
            let show_delete_buttons = `
            <a class="btn btn-warning mx-2" onclick="showTeamPage()" role="button">
            Show ${data['city']} ${data['name']}
            </a> 
            <a class="btn btn-danger mx-2" onclick="deleteTeam()" role="button">
            Delete ${data['city']} ${data['name']}
            </a> 
            `
            placeholder_div.innerHTML += show_delete_buttons;
        })
}

function showTeamPage() {
    fetch("http://localhost:5000/grab_team_to_view_or_edit", { method: "GET"})
        .then( response => response.json() )
        .then( data => {
            // Clear the div out
            let placeholder_div = document.getElementById("ajax_data_placeholder");
            placeholder_div.innerHTML = "";
            // Now display the team
            let team_info = `
            <h1>${data['city']} ${data['name']}</h1>
            <p>Team #${data['id']}</p>
            <p>Stadium name: ${data['stadium_name']}</p>
            `;
            placeholder_div.innerHTML = team_info;
            // Dispaly edit and delete buttons
            let edit_delete_buttons = `
            <a class="btn btn-warning mx-2" onclick="editTeamPage()" role="button">
            Edit ${data['city']} ${data['name']}
            </a> 
            <a class="btn btn-danger mx-2" onclick="deleteTeam()" role="button">
            Delete ${data['city']} ${data['name']}
            </a> 
            `
            placeholder_div.innerHTML += edit_delete_buttons;
        })
}

function editTeamInDB(e) {
    e.preventDefault();
    console.log("Editing team...")
    var searchForm = document.getElementById('team_edit_form');
    var form = new FormData(searchForm);
    fetch("http://localhost:5000/edit_team_ajax", { method: "PUT", body: form})
        .then( response => response.json() )
        .then( data => {
            // console.log(data);
            // Clear the div out
            let placeholder_div = document.getElementById("ajax_data_placeholder");
            placeholder_div.innerHTML = "";
            // Reset the dropdown menu to reflect updated team name
            let teams_div = document.getElementById("listed_teams");
            teams_div.innerHTML = "";
            new_team_HTML_string = '<select name="team_id">';
            for (let k = 0; k < data["all_teams"].length; k++) {
                const this_team = data["all_teams"][k];
                new_team_HTML_string += `<option value="${this_team['id']}">${this_team['city']} ${this_team['name']}</option>`;
                // If team ID matches the one we edited, then show that team
                if (this_team["id"] == data["this_team_id"]) {
                    // Now display the team
                    let team_info = `
                    <h1>${this_team['city']} ${this_team['name']}</h1>
                    <p>Team #${this_team['id']}</p>
                    <p>Stadium name: ${this_team['stadium_name']}</p>
                    `;
                    placeholder_div.innerHTML = team_info;
                    // Dispaly edit and delete buttons
                    let edit_delete_buttons = `
                    <a class="btn btn-warning mx-2" onclick="editTeamPage()" role="button">
                    Edit ${this_team['city']} ${this_team['name']}
                    </a> 
                    <a class="btn btn-danger mx-2" onclick="deleteTeam()" role="button">
                    Delete ${this_team['city']} ${this_team['name']}
                    </a> 
                    `
                    placeholder_div.innerHTML += edit_delete_buttons;
                }
            }
            new_team_HTML_string += "</select>";
            new_team_HTML_string += `<input type="submit" value="Select team">`;
            teams_div.innerHTML = new_team_HTML_string;
        })
}