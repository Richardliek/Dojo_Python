# Introduction to MySQL

Databases are ubiquitous - they're used in nearly every major website out there.  They're also utilized by many companies in a variety of fields, such as holding patients' records in a pharmacy, hospital, etc.

So what is a database?  A **database** is just a machine that holds data permanently so that it can accessed at any time.  When you browse the internet and log into a site such as Facebook, Amazon, eBay, Pinterest, etc., it grabs data linked to you - like who your friends are, what you've bought in the past, etc.  All of this information is stored in databases.

One of the most commonly used databases is MySQL.  SQL (pronounced like "sequel" or phonetically through its letters, so "S-Q-L") is a relational database, so in other words data is stored into tables with columns and rows and then tables can be linked together.

## Database design and relationships

Knowing how two items relate to each other is very important in guiding you when it comes to designing your database.  There are three different types of relationships:

- One-to-one
- One-to-many
- Many-to-many

Here are some examples:

- One-to-one: person with a driver's license, person with a social security number, business with a license
- One-to-many: author with books (assuming only one author per book), teams with players (assuming a player only has one team), a state/province/country with cities, users and online posts
- Many-to-many: performers and movies, users and friends

There are two questions you should ask yourself to determine the type of relationship (X = one item, Y = the other item):

1. Can one of X have many of Y?
2. Can one of Y have many of X?

If the answers are:
- "Yes" to both: many-to-many
- "Yes" to one and "No" to the other: one-to-many
- "No" to both: one-to-one

Let's imagine this scenario: you're building an online store where there is an inventory of items one can order.  Now an order is processed.  Can one order have many items?  The answer is yes.  Can an item be found in many orders?  The answer is also yes, because many different people can buy that item.  Thus orders and items would be many-to-many.

Now let's keep going with users and orders.  Can a user have many orders?  Yes.  Can the same order be linked to multiple people.  The answer is no.  Thus users and orders is a one-to-many relationship.

**Naming tables:** You should name your tables using plural nouns, so in other words, "users", "books", etc. and not "user", "book".  You are storing a lot of users, books, etc.

## Data types

Each table in your schema will be a set of items, such as books, users, players, teams, movies, cars, etc.  You have a lot of flexibility in deciding what to store.  You will be adding columns for each table, such as title and release date for a movie, and you will have to decide what kind of data you will want to store.  For example, title would be some sort of text field, while release would be some sort of date field.  There are many data types out there, and here are some of the common ones:

- VARCHAR(X) - X = number of characters
- CHAR(X) - like VARCHAR, but amount of space is fixed, so a field like postal abbreviations would use this
- INT - for integers (whole numbers)
- BIGINT - much bigger integers
- TINYINT - for small integers and booleans (1 = True, 0 = False)
- FLOAT
- TEXT - for storing huge amounts of text
- DATETIME - has the format YYYY-MM-DD hh:mm:ss, stored in local time
- DATE - only month, day and year

If you're curious, you can read more on other data types [here](https://dev.mysql.com/doc/refman/8.0/en/data-types.html).

**TIP:** *Always* use VARCHAR(255) to allow for the maximum flexibility.  VARCHAR columns only take up as much space as needed.  This is VERY important when we store hashed passwords for login and registration in a few weeks!

## Default values

When you design your database, you might want to give default values for certain columns.  When you add columns to your tables, you can specify default values so that when a record - as in a row - is added to your database, it'll automatically fill in for you.  Here are some defaults you should use for all your tables:

- created_at column: type "NOW()" to put in the current time
- updated_at column: type "NOW() ON UPDATE NOW()" to put in the current time upon creation, and then automatically change the time whenever there's an edit to a record

## Primary and foreign keys

In your tables, there needs to be a way to uniquely identify each record, or row.  That's what a **primary key** is used for - it is a value that is unique for each row.  Usually the primary key will be an id.

**IMPORTANT:** When creating your tables, always start with your primary key!  Make sure PK (primary key), NN (not null) and **AI (auto-increment)** are checked, and make sure it's an INT (or maybe BIGINT) field!  Auto-increment will increase the value of the primary key each time.

Data are often connected, and in MySQL this is no exception.  You will be connecting - or joining - tables.  The way to accomplish this is through a **foreign key**, which links one table to another.  The value of the foreign key will be an id value that identifies a record in a different table.  For example, you might have a table of authors, and in the books table you will have a foreign key called author_id that identifies which author is linked to that book.

**NOTES on the foreign key**:
1. You should set the "on delete" to "cascade" with your foreign keys.
2. The name of the foreign key should be singular, like "book_id" or "user_id", NOT "books_id" or "users_id".  You are linking to only one item at a time.
3. Foreign keys are used in all relationships - one-to-one, one-to-many and many-to-many.  In the many-to-many relationship, you will use two foreign keys and a middle table.