# Overview of MySQL queries

Now we will learn how to handle data with your database.  When you forward-engineer your database, you will generate your tables, which are part of your schema.  Each table will have **records** of values, which are basically rows in your table.  Each record will usually have values for each column you define in the table.

## CRUD operations

When interacting with your database, you'll need to know the CRUD operations.  CRUD stands for Create, Read, Update and Delete (or Destroy).

Each query must end in a semicolon `;`.  You can have the query span multiple lines for legibility; just remember to end the query with that semicolon symbol.

For reference, we'll use this schema:
![Cars and manufacturers schema](cars_manufacturers_schema.png)

### Create
To add a record into your database, type one of the following:
```sql
INSERT INTO table_name (column_name1, column_name2) VALUES (value1A, value2A); -- One set of values
INSERT INTO table_name (column_name1, column_name2) VALUES (value1A, value2A), (value1B, value2B); -- For two or more sets
```
For example, to insert Ford as a manufacturer:
```sql
INSERT INTO manufacturers (name) VALUES ("Ford");
```

### Read
To grab all the records from a table:
```sql
SELECT * FROM table_name;
```
So to grab all the cars:
```sql
SELECT * FROM cars;
```
You can narrow your search down in many ways.  For example, to grab one car:
```sql
SELECT * FROM cars WHERE id = 3;
```
This will grab the one car in the cars table whose primary key of id is equal to 3.  The `WHERE` keyword is used to specify a condition or set of conditions.  You can have more than one condition by using `AND`, `OR`:
```sql
SELECT * FROM cars WHERE id >= 2 AND id <= 5;
```

### Update
You can update records if you need to change a value or set of values:
```sql
UPDATE table_name SET column_name1 = value1, column_name2 = value2 WHERE some_condition = value;
```
After the word `SET` you specify column/value pairs, each of which is separated by a comma.

**IMPORTANT:** Remember to have a `WHERE` clause, otherwise you could update EVERY row in your table, which is dangerous!!

Here is one example:
```sql
UPDATE cars SET name = "Camaro" WHERE id = 5;
```
This will update the row whose id is 5 and change the value of the name to "Camaro".  You should usually use the primary key in the `WHERE` clause.

### Delete
You can always delete records too:
```sql
DELETE FROM table_name WHERE id = value;
```
**IMPORTANT:** Don't forget the `WHERE` clause, otherwise you might delete your entire table!
For example:
```sql
DELETE FROM cars WHERE id = 8;
```

## Joins
SQL is a relational database, which allows users to connect - and thus relate - tables to one another.  The two most common joins used are **(INNER) JOIN**s and **LEFT JOIN**s.  An inner join is used to connect two tables and show *only* the records from both tables that connect to each other.  Here is the general syntax:
```sql
SELECT * FROM left_table
JOIN right_table ON left_table.some_id = right_table.some_id;
```
You use a foreign key in one table to connect to the primary key in another table.  Here is an example:
```sql
SELECT * FROM manufacturers
JOIN cars ON manufacturers.id = cars.manufacturer_id;
```
This will show ONLY the manufacturers that have at least one car linked.  

But suppose you want to show ALL the manufacturers regardless of the number of cars made.  A **left join** shows all the data in the left table regardless of if there's any connections to the right table.  Here is a demo:
```sql
SELECT * FROM manufacturers
LEFT JOIN cars ON manufacturers.id = cars.manufacturer_id;
```
You can even narrow the results down to just a manufacturer:
```sql
SELECT * FROM manufacturers
LEFT JOIN cars ON manufacturers.id = cars.manufacturer_id
WHERE manufacturers.id = 2;
```
This will show the manufacturer whose ID is 2, and cars - if any (none will show up as NULL in the cars columns) - linked.

If you didn't do a left join, you WILL NOT grab the manufacturer if they haven't had a car linked to them:
```sql
SELECT * FROM manufacturers
JOIN cars ON manufacturers.id = cars.manufacturer_id
WHERE manufacturers.id = 2;
```
Thus this query could give you an empty result.

**WARNING:** If you don't include the table name after the where clause, you likely will get an error because the column "id" exists in both tables, so you have to specify which table.

### Other resources:

A student kindly shared this sheet and video link:
- Cheat sheet: https://programmingwithmosh.com/wp-content/uploads/2019/03/SQL-Cheat-Sheet.pdf 
- Based off of this YouTube video: https://www.youtube.com/watch?v=7S_tz1z_5bA

SQL join visual:
![Visual of joins](https://www.codeproject.com/KB/database/Visual_SQL_Joins/Visual_SQL_JOINS_orig.jpg)
The visual comes from this article:
https://www.codeproject.com/Articles/33052/Visual-Representation-of-SQL-Joins.

This visual shows all the different types of joins you can use.  You'll mainly use the left and inner joins.  You might use self-joins as well, which is basically joining a table back to itself.  