# Functions, conditional statements, loops (including lists of dictionaries)

## Tabs and spaces

Python is *very* sensitive about tabbing and spaces.  By convention, tabs are groups of 4 (or sometimes 2) spaces.  Here is an example:

```py
def hello():
    print("Hello there!") # This line IS part of the function since it's to the right of the "def"
print("Hi world!") # This line is NOT part of the hello function
```

Tabs and spaces are used to denote which lines of code belong to a function, a conditional block of code (if statement), inside a loop, etc.  So make sure you pay close attention!  The basic rule of thumb is: if it's part of the code block, use a tab/group of spaces.

## Conditional (if) statements

Sometimes you only want to perform an action whenever a condition - or set of conditions is met.  Imagine this scenario: you're in a parking garage and you need to find a place to park.  You can only park when you find an empty spot.  So in essence, you have this:
```py
if the current spot is empty:
    park the car
else: # Here the spot is filled
    keep driving
```
So when a condition is true, the code directly underneath - *and* indented to the right - will run, but if it isn't true, it won't run.  In this real-life situation, if you find a spot that is empty, you go ahead and park the car.  If the spot were not empty, we would continue driving - which is the "else" block; it only runs when all the other sets of conditions fail.  You wouldn't want to park your car where someone has already parked theirs!

(By the way, that snippet above is an example of **pseudocode**, where you write out the general idea of what you want to do with the logic organized, but the full code itself isn't written out.)

Here is the general structure of the if block:
```py
if condition_is_true:
    # Run this block of code here
elif this_other_condition_is_true:
    # Run this second block only
elif this_third_condition_is_true:
    # Run this third block
else:
    # Run this block if ALL the others are false
```
You can have as many `elif` clauses as you want - and it's even optional.  The `else` clause only runs if every other set of conditions before that is false.  **IMPORTANT:** When one set of conditions is satisfied, the code will continue executing *after* the else block, *even if another set of conditions is true afterwards.*

Here is an example:
```py
x = 50
if x > 20:
    print("x is bigger than 20")
elif x > 15:
    print("x is bigger than 15")
else:
    print("x is 15 or less")
print("End of if block")
```
In this scenario, the output would be:
```
x is bigger than 20
End of if block
```
Notice that the "x is bigger than 15" statement doesn't print, even though that condition is true.  This is because the first condition, `x > 20`, is true, so it won't check the others.

You can combine conditions like so:
```py
if x >= 10 and x <= 20:
    print("x is from 10 to 20")
else:
    print("x is not between 10 and 20")
```
```py
if x < 0 or x > 10:
    print("x is not from 0 to 10")
```

The `and` keyword is used when two or more conditions must be true.  The `or` keyword is when only one needs to be true.

You can also use the word `not` to reverse a True/False value.  So for example, `if not is_happy` would reverse the value of the variable `is_happy`.

## The pass keyword
Python expects code within a code block at all times.  But sometimes you don't know immediately what code you need to write, and that's true for all of us.  The `pass` keyword is used to represent a placeholder essentially until we have a better idea of what to actually do:

```py
if x > 10:
    pass # We don't know what to do here yet, but we'll put something later on, so for now use the keyword "pass"
```

## Functions

Just like in JavaScript, we have functions in Python.  A **function** is a block of code that will run when it's called.  Functions are useful to reduce redundancy; in other words, don't repeat yourself.  Here is how to create a function:

```py
def function_name(): # Functions start with the "def" keyword; think of it like the "function" keyword in JS
    pass
```

### Returning vs. printing values
Let's imagine that we want to calculate the volume of a box.  Here is one way to implement it:
```py
def volume_of_box(x,y,z):
    print(x*y*z)

volume_of_box(3,4,5)
```
Note that you must call the function in order for it to run.

In this example, you would see 60 print out.  But suppose you need to do something with that value afterwards.  Like what if we wanted the volume of 10 of those boxes?

```py
def volume_of_box(x,y,z):
    return x*y*z

box_volume = volume_of_box(3,4,5) # box_volume = 60
print(f"The volume of 20 boxes is {20*box_volume}")
```
Notice the `return` keyword - it's used to get a value from the function, and then we can do something with it afterwards.  We've taken the calculated volume and stored it in a variable called `box_volume`.  And then the print statement shows the volume of those 20 boxes.

**Remember:** Returning a value is NOT the same as printing a value.  If you try to print a function that doesn't return anything, you'll get the value `None` because the function never returned a value!

### Parameters and arguments

Notice in the `volume_of_box` function that there were three variables in the parentheses: x, y and z.  These are called **parameters**; they represent placeholders that hold values that will be given to the function to be used later.

When the function is called, like `volume_of_box(3,4,5)`, the values 3, 4 and 5 are called **arguments**.  They are the actual values that will be given to the function.  Thus x, y and z are 3, 4 and 5, respectively.  Note that you can always pass variables as arguments as well:

```py
length = 5
width = 3
height = 10
this_volume = volume_of_box(length, width, height)
```

Nifty tip - you can define multiple variables in one line:
```py
length, width, height = 5, 3, 10
```

### Optional parameters
Sometimes you want to write a function that will not need certain arguments.  The way to accomplish this is through **optional parameters**.  Here is an example:

```py
def charge_item(price, quantity = 1):
    return price*quantity

print(charge_item(5.99)) # Prints 5.99 (5.99 * 1)
print(charge_item(20,5)) # Prints 100 (20 * 5)
```
In the first charge_item() call, we only used one argument: 5.99 for price; since no quantity was specified, the default value of 1 is used.  In the second call with 20 and 5, the price is 20, and the quantity is 5 since that was given as an argument.

**IMPORTANT:** Optional parameters MUST go at the end of the definition of your function; you can't mix and match in terms of order.

Definitely read the platform since it goes more in depth than I do: https://login.codingdojo.com/m/309/9251/62279.

## Loops

A loop is used when you will run the same block a code a certain number of times.  A **for loop** is most often utilized when you know when you'll start and when you'll finish, whereas a **while loop** is used when you don't know beforehand how often you will rerun a block of code, but you know when you will finish.

The most common application of a for loop is to go through the items in a list or dictionary.

### Looping through a list (or tuple)
Here is an example:

```py
my_list = [8, 4, 7, 3, 2]
for k in range(len(my_list)): # For each index in the list - note the len() function to get the number of items in the list
    print(my_list[k]) # Print the value at that index
```

The `range()` function is used to get a sequence of numbers.  For example, `range(7)` gives the sequence (0, 1, ..., 5, 6).  Notice that 7 is NOT included!  You can also specific a starting number: `range(4,10)` gives (4, 5, 6, 7, 8, 9).  And you can increment by a value other than 1: `range(5,13,2)` gives (5, 7, 9, 11) - note there's no 13.  And you can go backwards: `range(5,1,-1)` gives (5, 4, 3, 2) - there is no 1 at the end.

Here is an alternate way to loop through the list:
```py
my_list = [8, 4, 7, 3, 2]
for val in my_list:
    print(val) # Print the value - note that the index is not used at all in this loop
```

Tuples can be looped through the same way as a list.

### Looping through a dictionary
Let's demonstrate how to loop through a dictionary:
```py
my_dictionary = {
    'color': 'blue',
    'number': 10,
    'menu': {
        'burger': 1.99,
        'pizza': 2.99,
        'soda': 0.99
    },
    'city': 'Seattle',
}
for key in my_dictionary:
    print(key) # Prints the name of the key - so 'color', 'number', etc.
    print(my_dictionary[key]) # Prints the value linked to the current key
```

You can retrieve just the keys or just the values by calling on the `keys()` and `values()` methods, respectively.  For example:

```py
for val in my_dictionary.values():
    print(val) # Prints 'blue', 10, etc.
```

### Looping through a list of dictionaries (IMPORTANT for down the road!)
Later on in the course we will looping through a list of dictionaries *a lot* when we pull data from a database, so get comfortable with this sooner than later.  Let's demonstrate with an example:

```py
this_list = [
    {
        'name': 'Adrian',
        'state': 'Washington',
        'number': 88,
        'color': 'yellow',
    },
    {
        'name': 'Mary',
        'state': 'Oregon',
        'number': 22,
        'color': 'blue',
    },
    {
        'name': 'John',
        'state': 'Wyoming',
        'number': 34,
        'color': 'red',
    }
]
for item in this_list:
    print(item) # Will print each dictionary individually so "item" is a different dictionary
    print(item['name']) # Will print 'Adrian', 'Mary', 'John'
```

### While loops
The general structure of a while loop looks like this:
```py
while (condition_is_true):
    # Run your code here
```
IMPORTANT: Make sure the variable(s) you are using for your conditions are changing value, otherwise you could easily be stuck in an infinite loop, which is not a good thing, to say the least.

Here's an example problem: let's try to find the smallest number N so that 1 + 2 + 3 + ... + N is >= 500.  We can use a while loop to solve this:

```py
sum = 0
val = 0 # Must start at 0, NOT 1, otherwise the answer will be slightly off
while sum < 500:
    val += 1 # Increment val by 1 each time, so the first value we'll add is 1...
    sum += val # ...then add the value sum must change for each iteration since that's the variable we're checking in the condition
print(val)
```
In this case, the value we want is 32 since 1 + 2 + 3 + ... + 32 = 528.

### The break and continue statements in loops
If you need to exit a while or for loop early, you can use the `break` statement:
```py
x = 3
for y in range(10):
    if y > 2*x:
        break # Exit the loop immediately with this statement
```
If you just want to jump to the next iteration of a loop, use the `continue` statement:
```py
for y in range(20):
    if y % 3 == 0:
        continue # Go straight to next iteration, or the next value of y in this case
    print(y)
```
This loop prints all the values from 1 through 19, inclusively, that are NOT divisible by 3.