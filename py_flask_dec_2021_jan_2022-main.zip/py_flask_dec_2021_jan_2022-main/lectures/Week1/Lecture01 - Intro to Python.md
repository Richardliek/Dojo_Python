# Welcome to Python!

Welcome to the Python course in Coding Dojo!  My name is Adrian, and I will be your instructor.  Your TA for the course is Alayne.  We will be spending the next 8 weeks together learning Python, MySQL and Flask.  When you are done with the 8 weeks you can build a functioning website with a database!  Many sites were built with Flask - including Pinterest!

Here is the course schedule we'll use: https://docs.google.com/spreadsheets/d/1xAK4FIuZDefR0YrnWUUKIPmgMTMkt1QPqbL8IQ9iNTM/edit#gid=2097812438

## Useful settings and extensions for Visual Studio Code

As you might have noticed, Python is *very* sensitive when it comes to spacing and tabs.  Sometimes it's easy to see them, but sometimes it isn't, especially at the end of a line.  We can display those easily by tweaking a particular setting in VS Code in order to render those spaces and tabs in the background as dots and arrows, respectively.  To change this setting, go to "File" -> "Preferences" -> "Settings", then type in "Whitespace", and if it works, you should see "Editor: Render Whitespace" as a setting pop up.  Change the value to "All" (default is "selection", i.e. you only see them when you highlight text).

There are other extensions that could come in handy: indent-rainbow to show groups of tabs and spaces, and the material icon theme for nicer icons of your files.

## Basics of Python

When you want to run some Python code, *make sure you're in the folder that has the file you want to execute*.  Once you've navigated there, type the following: `python file_to_run.py` (Windows/Linux) or `python3 file_to_run.py` (Mac - notice the "3" in the command "python3").

### Variables and primitive data types

In Python, all you need to do to define a variable is `variable_name = value_to_store`, e.g. `x = 15`.  Notice there's no "var", "let" or "const" like in JavaScript.

Variables can hold any type of value you want:
- Boolean: `True` or `False` - note the capitalization!
- Numbers: `10`, `-22.5`, etc.
- Strings: `"Hello world!"` - we'll talk about strings a little farther down
- Special value: `None` (effectively equivalent to `null` in JavaScript)

If you need to check the type of variable, e.g. int, float, you can use the `type()` method: `type(variable_name)`.

You can convert between data types as well: some of the functions you can use are `int()`, `float()`, `str()`, etc.

There are other data types as well we'll talk about in a bit.

### Displaying output

In JavaScript, you would type `console.log(value)`.  In Python, the equivalent would be `print(value)`.  I *highly* advise using print statements to check your code in case you run into bugs and errors, which you very likely will.  

Who's perfect anyway?!

### Comments in code

You can add comments to your code.  In fact I would recommend it for all the important parts so that you can explain in your own words what that section of code is doing.  You will see a lot of my code will contain comments - it's a good habit, especially when you collaborate with others down the road!

```py
# This is a one-line comment.
x = 10 # Comments can go at the end of a line.

"""
This is a
multi-line comment.  
Notice the three " (double-quotation marks) 
at the start 
and end of the block comment.
"""
print(x) # Display the value of x in the console or terminal.
```

### Strings

Strings are a collection of characters put together.  You can concatenate, i.e. put together, multiple strings and values:

```py
x = 5
print("The value is", x)
print("The value is " + str(x)) # Notice the space after the word "is"
```

Notice two things:
1. When you use commas to separate items in a print() function, spaces will *automatically* be inserted, whereas with the plus sign, +, they will not, so you will have to put those in yourself. 
2. If you use the plus sign, +, you MUST convert any non-string values first.  

**String interpolation** is used to inject, or insert, a value into a string.  This is accomplished through an f-string.  Here is an example:
```py
x = 12
print(f"x is {x}.") # Don't need to convert x into a string
```
This is equivalent in JavaScript to:
```js
let x = 12;
console.log(`x is ${x}.`); // Notice the back-tick marks ` (found to the left of the "1" key on the keyboard)
```

There are many methods you can use for strings.  Many of them can be found [here](https://www.w3schools.com/python/python_ref_string.asp) (not an exhaustive list - don't memorize these).

### Importing modules and code

Oftentimes in code you will need to import files, modules, etc.  It would very unwieldy to have a program in production run on a single file, so it's broken up to make things more manageable.

Python comes with a lot of stuff out of the box, but occasionally you'll need to import modules.  Some common modules include the random module, the regex module (called "re"), datetime and date, etc.  Here's how to import:

```py
import module_name # Put import commands at the top of the file!
```
Or to import a function or variable specifically from a module:
```py
from module_name import method_or_variable_name
```
For example, if you want the function that generates a random number from X to Y:
```py
from random import randint

x = 10
y = 20
z = randint(x, y) # Generates a number from 10 to 20, inclusively
```

If you import the entire module called `random`, then the code would go like this instead:
```py
import random

x = 10
y = 20
z = random.randint(x, y) # Note the module name, then the method name
```

We will be doing a lot more importing when we combine Flask and MySQL, so stay tuned.

### Lists vs. dictionaries vs. tuples

We can hold groups of items together, just like in JavaScript.  An array in JavaScript is called a **list** in Python, and it uses the same notation:
```py
my_list = ["Hello", "World", 15, True, None, -4.5]
```

The methods you can use are a bit from JavaScript in some respects: in Python, to add something to the end of a list, you use the `append()` method (called push() in JavaScript), but in both languages, you use `pop()` to remove something from the end.

You can **slice** lists in Python, so you can grab a specific sequence of items:

```py
x = [8, 3, 4, 7, 2, 5]
print(x[1:]) # Prints [3, 4, 7, 2, 5]
print(x[2:4]) # Prints [4, 7], NOT [4, 7, 2]
print(x[:4]) # Prints [8, 3, 4, 7]
print(x[::2]) # Prints [8, 4, 2]
```

An object in JavaScript is called a **dictionary** in Python:
```py
my_dictionary = {
    "number": 1,
    "name": "Adrian",
    "is_happy": True,
}
```

You can build lists of dictionaries (IMPORTANT for later), lists of lists, dictionaries with lists, etc.  Here is a list of dictionaries:
```py
my_books = [
    {
        "title": "1984",
        "author": "George Orwell",
    },
    {
        "title": "The Old Man and the Sea",
        "author": "Ernest Hemingway",
    },
    {
        "title": "Harry Potter and the Goblet of Fire",
        "author": "J. K. Rowling",
    },
    {
        "title": "The Great Gatsby",
        "author": "F. Scott Fitzgerald",
    },
    {
        "title": "Jane Eyre",
        "author": "Charlotte Bronte",
    },
]
```

To grab the book by Fitzgerald, you would type `my_books[3]` to grab that dictionary, then to grab the title, type `my_books[3]['title']` to get "The Great Gatsby".

A **tuple** is basically a list, but you can't change its values.  It's useful for anything whose values you DON'T want to change - so in a sense, the values are "read-only".  Here is a tuple:

```py
my_tuple = (1, 4, 8)
print(my_tuple)
# my_tuple[0] = 3 # Will give an ERROR since you can't change a tuple's contents
```

Feel free to read up more on lists, tuples, dictionaries, sets, etc. [here](https://docs.python.org/3.9/tutorial/datastructures.html).