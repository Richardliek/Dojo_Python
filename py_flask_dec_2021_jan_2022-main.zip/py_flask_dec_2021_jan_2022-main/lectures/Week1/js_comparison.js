console.log("Hello JavaScript!");

var x = 10;
let y = 5;
const z = 3;

var is_hungry = true;

x++; // Increase by one
x += 5; // Increase by five
x -= 7;
x--; // Decrease by one

/*
This is 
a multi-line
comment.
*/

var message = "Hello!"

console.log(`The value of x is ${x}`);

var x2 = [3, 8, "Hello", false];
var x3 = [];

console.log(x2[1]);

x2.push(15);
x2.pop();

console.log(x2.length);

// Objects
var my_obj = {
    "number": 10,
    "name": "Adrian",
    "is_happy": true
}

let k = 5000;

if (k > 100) {
    console.log("k is bigger than 100");
} else if (k > 50) {
    console.log("k is bigger than 50");
} else {
    console.log("k is 50 or less");
}

// function name_of_function() {
    // return a value here
// }

// Print the values 1 through 10
for (var i = 1; i <= 10; i++) {
    console.log(i);
}