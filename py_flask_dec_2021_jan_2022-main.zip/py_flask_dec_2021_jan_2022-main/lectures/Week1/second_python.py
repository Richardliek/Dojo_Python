k = 5000
# Demonstrate of if block
if k > 100:
    print("k is bigger than 100")
    print("Another line") # Part of if block
elif k > 50: # Will not run if first block executes, even if this statement is true
    print("k is bigger than 50")
else:
    print("k is 50 or less")

def volume_of_cylinder():
    pass # Every block of code needs at least one line indented, and if you don't know what you'll put in yet, use the "pass" keywoard as a placeholder

# Demonstrating functions and parameters
def do_chores(chore):
    print(f"Doing {chore}")
    print("All done!")

do_chores("dishes")
do_chores("laundry")
do_chores("homework")
# do_chores() # Gives an error - you must pass a value in

# # Returning a value vs. printing a value
def multiply_numbers(x,y):
    print(x*y)

# print(10*multiply_numbers(5,10)) # ERROR - we get None

def multiply_numbers_returned(x,y):
    return x*y

print(multiply_numbers_returned(5,10))

# Using the number from the function as part of a calcuation
total_number = 100*multiply_numbers_returned(5,10)
print(total_number)

# Demonstrating looping through a sequence of values with a for loop and the range() function
for i in range(11,0,-2):
    print(i)

my_list = [8, 4, 1, -5, 3, 6, 11]

# Loop through the values - without the index
for i in my_list:
    print(i)

# Another way to loop - with the index used
for i in range(len(my_list)):
    print(my_list[i])

# Max value in list
max_value = my_list[0]
# Loop through list
for i in range(1, len(my_list)): # Start at index 1
    if my_list[i] > max_value: # If new biggest value found
        max_value = my_list[i] # Make this new max
print(f"Max value: {max_value}")

# Loop through a list of dictionaries
some_list = [
    {
        'food': 'pizza',
        'price': 15,
        'ratings': [10, 9, 8, 9]
    },
    {
        'food': 'sushi',
        'price': 20,
        'ratings': [7, 9, 8, 9, 10]
    },
    {
        'food': 'pasta',
        'price': 15,
        'ratings': [8, 9, 8, 9]
    },
    {
        'food': 'pho',
        'price': 12,
        'ratings': [8, 7, 8, 10, 10]
    },
]

for dictionary in some_list:
    print(dictionary['food']) # Print food
    print(f"{len(dictionary['ratings'])} ratings:") # Print number of ratings for this food
    for rating in dictionary['ratings']: # Print each rating
        print(rating)

print(some_list[2]['ratings']) # Print list of ratings for 'pasta' (at index 2 in list)

# 1 through 400 in increments of 9
for x in range(1,401,9):
    print(x)

# X through Y in increments of Z - returning a new list
def list_values(x,y,z = 1):
    new_list = []
    for val in range(x, y+1, z):
        new_list.append(val)
    return new_list

print("-------------")
print(list_values(5,1000)) # Using default step size of 1
print(list_values(5,1000,10)) # Using our own step size of 10