# import datetime
from datetime import datetime
import random

# print(datetime.datetime.now()) # If you use "import datetime"
print(datetime.now())
print(datetime.today())
print(random.randint(10,50))

print("Hello Python!")

x = 10
y = 5
z = -2.84789

is_hungry = True # Must start True or False with a capital letter

x += 5 # Increases x by 5
x += 1 # Increase x by 1; there is no ++ or -- in Python
y -= 3 # Decrease y by 3
longer_variable_name = 15

"""
This is 
a multi-line
comment.
"""

this_message = "Hello!"
another_message = 'Hi!'

# print("The value of x is", x) # When you use a comma, the space will automatically be added
# # print("The value of x is"+x) # Produces an error
# print("The value of x is "+str(x)) # Spaces must be added yourself when you use the "+"

# F-strings
print(f'The value of x is {x}')

x2 = [3, 8, 'Hello', False]
x3 = []

print(x2[1]) # Grabs and prints the item at index 1 (value 8)

x2.append(15)
x2.pop()

print(len(x2))

# Slicing a list

print(x2[2:]) # Prints ['Hello', False]

# (starting index):(ending index - first index to EXCLUDE):increment
print(x2[:2]) # Prints [3,8], NOT [3, 8, 'Hello']

print(x2[::2]) # Prints [3, 'Hello']

# Tuple
my_tuple = (5, 8, 3, 7) # Immutable - can't change its values
# my_tuple[1] = 3 # ERROR - can't change a tuple's values

# Dictionaries

my_obj = {
    "number": 10,
    "name": "Adrian",
    "is_happy": True,
}

print(my_obj["is_happy"]) # Prints True

# List of dictionaries:
my_list = [
    {
        'name': 'Michelle',
    },
    {
        'name': 'Adrian',
    },
    {
        'name': 'Carlos',
    },
    {
        'name': 'Brian',
    }
]

print(my_list[1]) # Print the dictionary at index 1
print(my_list[2]['name']) # Print the value linked to the "name" key