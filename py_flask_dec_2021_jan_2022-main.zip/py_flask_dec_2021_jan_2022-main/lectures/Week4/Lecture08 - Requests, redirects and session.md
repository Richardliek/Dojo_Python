# Forms, redirects and session

When you click on a link, you are submitting a request to get information from a site.  What is happening is that the client is submitting what's called a **GET request**, which fetches data from a server.  By default, clicking links, typing in the link, etc. will send a GET request.

But suppose you fill out a form where you have to enter information, like credit card data in order to buy something online, or your email and password to log into a site that you've made an account for, like Facebook, Reddit, etc.  When forms are used to send data, it's possible to send the data through a different type of request called a **POST request**.  A POST request is used whenever sensitive data is being sent from the client to a server.  (It's called a POST request in the same way you send packages and letters through the post office - so you're actually posting parcels.)

There are many reasons why we use POST requests:
- If you DON'T send the data in the form as a POST request, it will show up in the URL.  Do you want to see sensitive data like that in the URL?!  With a POST request, the data won't show up.  Here is how the data would show with a GET request:
```
some_random_site.com/send?name=Adrian&pwd=password123
```
- You don't want to send sensitive data twice.  Imagine buying expensive wares from a store online - do you want to be charged twice?!

There are actually many types of HTML requests out there.  Unfortunately, HTML forms as they are can only support GET and POST requests.  In order to handle additional types of requests (e.g. PUT), you would need to use the Fetch API in a JavaScript file.

## Sending data through a form

### In the HTML file:
When creating a form in your HTML file, you will need the following:
  - "action" attribute inside your form tag: This specifies the route that you will send the data to.  For example, `<form action="/actors/new">`.
  - "method" attribute to specify your request: `<form action="/actors/new" method="POST">`.  If you don't include the method, it'll send a GET request by default, so you should nearly always method="POST".
  - A "name" attribute for each input: For example, for a text input, you will do: `<input type="text" name="first_name">`.  Whatever you put for the name is what you'll use in the back end when you retrieve the data from the form.
  - A way to submit the data: *Inside the form*, put `<input type="submit" value="Text to show for button">` OR `<button>Text inside button</button>`.  Do NOT use `<input type="button">`.

### In your back end (server.py, later on controller file):
First of all, remember to import request:
```py
from flask import Flask, render_template, request
```
To retrieve data from the form, call on `request.form['name_of_field']`.  With `<input type="text" name="first_name">`, you will use `request.form['first_name']` in the back end.  **IMPORTANT: Whatever you use for the name in the form MUST match what goes inside the square brackets in request.form[].** For example, name="**first_name**" in the HTML and request.form["**first_name**"] in the back end.  Make sure your spelling is EXACT!

To handle POST requests, you have to specify the POST method in your route:
```py
@app.route("/books/new", methods=["POST"])
def add_book():
    # Add your code here
    pass
```
By default, routes handle GET requests.  To have the route handle POST requests only, add "`methods=["POST"]`".  (You can actually have methods use more than one HTTP request; for example, type `methods=["GET","POST"]` to have the route handle GET and POST requests.)

TIPS: 
- Make sure you know how to handle empty inputs.  Ways you can check include request.form.get("field_name"), which will return `None` if nothing was submitted for the input with name = "field_name".
- You can use request.form.getlist("field_name") for fields where you can have multiple values selected.
- It's also possible that an empty input might actually have an unexpected value, like 0 or an empty string, so pay attention!
- Don't mix up "`methods=["POST"]`" (in the back end) and "`method="POST"`" (in the HTML)!

## Redirects

You probably have encountered redirects before coming to the boot camp.  One such example is when you go to a link, but then it appears there's practically nothing on the page.  You might get a message saying something along the lines of "redirecting to" another link.

A **redirect** is when a (GET) request gets sent to another route.  The situation just outlined is one example of a redirect - going to a different route that has the information that a client is seeking.  For example, an old link for a home page will redirect to a new link for that same page.

There's a more useful application for redirects for us, though.  Let's go back to the scenario where you are paying to buy merchandise online.  But you don't get shown a new page, so you might refresh it.  When refreshing it, though, you might get a pop-up window asking if you want to resend the data again.  Do you want to pay for the same item twice?

A redirect is used when a route is done processing data from a form.  Keep this important point in mind: **information stored in the request object only lasts for a single request.**  So if you were to refresh or go to another page, the data disappears.  So when you get redirected, the data in the form is gone because a new request has been made to redirect to another route.

The important item to remember is this: **ALWAYS REDIRECT WHEN HANDLING POST REQUESTS!**  Never, ever render an HTML file in a post route.

Here is how you create redirects:
```py
@app.route("/games/new",methods=["POST"])
def add_game():
    # Put code here
    return redirect("/games")
```
And don't forget to import redirect:
```py
from flask import Flask, render_template, request, redirect
```
The redirect function MUST specify a route - NOT an HTML file.  So don't do `redirect("some_page.html")`, for example.

## Session

When you submit data through a form, it's held by the request object.  Now when you click a link or redirect, the data from the form disappears because a new request is made.  Wouldn't it be nice if we could hold data for multiple routes?

There is!  It's called **session**.  Here is how to use it:

```py
from flask import Flask, render_template, redirect, session
app = Flask(__name__)
app.secret_key = "your_key_here" # New - need a secret key for session

@app.route("/")
def index():
    session["value"] = 10 # Don't use session to hold stuff from OOP!  Also don't save sensitive data in session!
    # Add other code here as needed.

@app.route("/increase")
def index():
    if "value" in session: # Check to see if a session variable called "value" exists
        session["value"] = session["value"] + 10
    # Add other code here as needed.
```
To utilize session, we have to import it AND use a secret key.  A secret key is used to identify your project - so don't upload it to a public location like GitHub if you can help it!

You can create session variables by doing `session["variable_name"] = value`.  You can delete session variables by doing `session.pop("variable_name")` and delete ALL session variables by doing `session.clear()`.

Session will pop up more when dealing with login and registration, so do NOT assume that you will use it to hold form data necessarily.

You can also use session variables in your HTML:
```html
<p>The value is {{ session["value" ]}}</p>
```
You do NOT need to pass session variables and values through the render_template() function.