from flask import Flask, render_template
app = Flask(__name__)

# localhost:5000
@app.route("/")
def demo_flask():
    return "<h1>Hello Flask!  I'm a string!</h1>"

# localhost:5000/welcome
@app.route("/welcome")
def welcome_page():
    number = 140
    my_list = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43]
    # Passing variables to an HTML file - make sure you have a templates folder!
    return render_template("hi_flask.html", value = number, prime_nos = my_list)

# Using path variables
@app.route("/hello/<int:count>/<word>") # word = string (default data type), count = int (integer)
def hi_page(count, word): # Need path variables as parameters
    return_str = ""
    for i in range(count):
        return_str += f"<h3>Hello {word}!</h3>"
    return return_str

if __name__=="__main__":
    app.run(debug=True)