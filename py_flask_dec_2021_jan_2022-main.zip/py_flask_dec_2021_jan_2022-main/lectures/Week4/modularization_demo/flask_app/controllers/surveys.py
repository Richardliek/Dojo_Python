from flask_app import app
from flask import render_template, redirect, request, session# ,flash
from flask_app.models import survey

# ALL your routes should go in your controllers

@app.route("/") # localhost:5000 (localhost:5000/)
def survey_page():
    return render_template("finished_survey.html")

@app.route("/surveys/new", methods=["POST"])
def process_survey():
    # request.form.get("first_name")
    # request.form.getlist("checkbox_field")
    print(request.form)
    session['first_name'] = request.form['first_name']
    session['last_name'] = request.form['last_name']
    session['email'] = request.form['email']
    session['number'] = request.form['number']
    session['important_date'] = request.form['important_date']
    session['color'] = request.form['color']
    # print(request.form["first_name"])
    return redirect("/surveys/results")

@app.route("/surveys/results")
def survey_results():
    return render_template("survey_results.html") 