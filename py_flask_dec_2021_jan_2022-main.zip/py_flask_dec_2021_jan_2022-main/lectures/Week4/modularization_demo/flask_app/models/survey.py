# from flask_app.config.mysqlconnection import connectToMySQL

# class Survey:

#     def __init__(self,data):
#         self.id = data["id"]
#         self.first_name = data["first_name"]

# Creating instances of your class, interacting with your database, doing validations, performing other logic, etc.