# Introduction to Flask

One of the web frameworks used to build websites is called Flask.  It was developed as an April Fools joke, oddly enough, but it's now one of the more popular frameworks for Python back-end developers.  The back end consists of servers, databases, and other stuff that isn't visible to a client or user.

Feel free to look at Flask's documentation - so save this as a bookmark: https://flask.palletsprojects.com/en/2.0.x.

Before we dive into Flask, it's useful to review the request-response cycle.  When a client - which is technically a machine; humans interact with hardware - makes a request, it is sent to a centralized server, which handles traffic for the app.  The server then decides what kind of response to give to the client, whether it's a web page, a redirect to another location (more on that in the next lecture), or some other response.  When a link is clicked or entered into the browser, like https://www.weather.gov, a request is being made to that site's server, and the server responds by sending a copy of the HTML page.

## Virtual environments

When you get into the development world, you will likely be working on several projects, perhaps concurrently.  Not every project is going to utilize the exact same packages and code.  That's one of the reasons we have virtual environments.  A virtual environment is used to keep track of which packages are being used for a project.  Another reason is to test code to ensure there are no errors locally before deploying - i.e. publishing - the app.

You will be using `pipenv` to create virtual environments and add/remove packages, among other tasks.  If you haven't done so, type `pip install pipenv` (Windows) or `pip3 install pipenv` to install the pipenv package globally on your machine.

Create a project folder where you will build your app.

**IMPORTANT:**
- Do NOT create a virtual environment while another one is active.
- Do NOT have nested projects or virtual environments; it's *highly* recommended to put virtual environments in child folders.  For example, you might have a parent folder called `work_projects` and a folder inside that called `social_media_project` - you should only have one virtual environment for `social_media_project`.  If you have multiple folders inside `work_projects`, each project inside that can have a separate environment.

**Creating a virtual environment for the first time:** While inside that folder, type `pipenv install flask` (you might have to add "`python -m`" [Windows] or "`python3 -m`" [Mac] if you run into problems).  If this runs successfully, you'll see files called 'Pipfile' and 'Pipfile.lock'.  They will contain the information on which packages and versions are being used for this project.

**You should ALWAYS have a different virtual environment for each of your projects.**  This will be important as later projects will have additional packages.

**Activating a virtual environment:** Inside the project folder, type `pipenv shell` to activate the environment.  To exit, type `exit`.

If you want to see which packages are installed, type `pipenv graph` *while the virtual environment is active.*

## Routing

Most popular sites have multiple routes.  For example, https://www.google.com/maps would open Google Maps, while https://www.google.com/calendar would open Google Calendar if you have an account.  Those are two different routes for Google's site - the routes are usually defined after the ".com"/".org"/".net", etc., so "/maps" and "/calendar" are two different routes.

In Flask, you will be defining your own routes!  Let's start by creating a server.py file in your project folder:

```py
from flask import Flask # Import the Flask class to create the app
app = Flask(__name__)

@app.route("/") # Decorate that defines our route - in this case, localhost:5000 (invisible forward slash at the end)
def welcome_page():
    return "<h3>Welcome to Flask!</h3>"

@app.route("/about") # Route: localhost:5000/about
def about_page():
    return "<p>This is a starter app in Flask!</p>"

if __name__=="__main__": # Allows file to be run directly
    app.run(debug=True) # Run app in debug mode (when published, this will be a False value for debug)
```

To run the app, make sure that your virtual environment is activated first, then type "`python server.py`" (or `python name_of_file_with_app_dot_run.py`).  Now go to whichever browser you want, and type "localhost:5000".  You should see "Welcome to Flask" appear.  Now try "localhost:5000/about".  If it works, you will see "This is a starter app in Flask!"

You will use the `@app.route()` decorator for each of your routes you'll define.  Inside the parentheses is the name of the route itself.  All your routes MUST start with "/", and don't include a "/" at the end - "/about" is different from "/about/".  These route names will go after "localhost:5000", so "localhost:5000/about".  (The "/" is the route for just plain "localhost:5000".)

**IMPORTANT FOR MAC USERS:** MacOS recently updated its OS and enabled AirPlay Receiver, which uses port 5000, creating a conflict.  To disable it, look at [this page](https://stackoverflow.com/questions/69818376/localhost5000-unavailable-in-macos-v12-monterey).

Another option is to change your port number in your server.py file:
```py
if __name__=="__main__":
    app.run(debug=True, port=5100) # Note the port number!
```
The port number can be any 4-digit number; just don't use 5000, 8000, 3000 or any others that might use a specific port.  In this example, you would run localhost:**5100**.

## Path variables

In many websites, there is usually something in the link that identifies a specific item being shown.  For example, when a person makes blog entries, there is usually something in the link that identifies a specific post.  For example, perhaps the site has a route called "/blogs/10".  The 10 means the blog with that given unique key.

It would be unwieldly to write code to define a route for each individual blog.  That's where path variables come into play.  Here is an example:

```py
@app.route("/blog/<id>")
def blog_post(id): # Parameters MUST match path variables
    return f"Blog post number {id}"
```
In your route, path variables are enclosed in the `<>` brackets.  Here we define a path variable called "id".

**IMPORTANT:** Path variables MUST be given as parameters to your function as well!

By default, all path variables are strings!  If you want to use a different data type, you can.  Here is a list from Flask's documentation: https://flask.palletsprojects.com/en/2.0.x/quickstart/#routing.

For example, you might use "`/blog/<int:id>`" to use the id as an integer instead of the default string type.

You can have as many path variables as you want; just remember to give them all to the function as parameters.

## Rendering HTML files
In all the previous examples, we've returned strings and snippets of HTML.  In reality, you will much more often than not return HTML files or redirects (see next lecture on redirects).

To render HTML files, you MUST create a folder named `templates` inside your project folder.  The spelling has to be exact - so not "template", "templtes" or any misspellings.  Inside the templates folder will be your HTML files.

To serve a client an HTML file, we call on a new method named `return_template()` - don't forget to import it at the top!

```py
from flask import Flask, render_template # NEW
app = Flask(__name__)

@app.route("/") # localhost:5000
def welcome_page():
    return render_template("welcome.html")

if __name__=="__main__":
    app.run(debug=True)
```
So when a user visits localhost:5000, they will see the welcome.html file.

## Passing values to the HTML file
You're not limited to fixed code in the HTML file.  You can pass values from the server to the HTML file.  This is accomplished through a templating engine called Jinja.  Here's an example of how to give variables to the HTML:

```py
from flask import Flask, render_template # NEW
app = Flask(__name__)

@app.route("/") # localhost:5000
def welcome_page():
    name = 'John'
    number = 40
    my_list = [3, 8, 17]
    return render_template("welcome.html", name = name, value = number, this_list = my_list)

if __name__=="__main__":
    app.run(debug=True)
```
Here in the render_template function we are passing three variables.

**IMPORTANT:** Whatever is on the left-hand side of the equal side is the name of the variable that is available to the HTML file.  That means in this example the HTML file has access to variables called "name", "value" and "this_list".

Now to show the values in the HTML, here's how:
```html
{# This is a comment in }
<p>My name is {{ name }}.</p>
<p>This number is {{ number }}.</p>
<p>List of numbers:</p>
<ul>
    {% for item in this_list %}
        <li>{{ item }}</li>
    {% endfor %}
</ul>
```
To render values, you use the double curly brackets: `{{ }}`.  You can loop through lists and dictionaries in the HTML, and perform if(-else) statements:
```html
{% if value in some_list %}
    <!-- Put your HTML code here -->
{% endif %}
```
Do NOT use the HTML file to perform complex operations; those should be handled in the back end, so through the server and/or other files.

## Linking static files

You can link CSS, JS, images, videos and other static content in your Flask project.  We call the content "static" because Flask doesn't have to process or modify the content inside.  All frameworks have a static section.

To hold static content, create a folder called "`static`" in your project folder.

Here is what your file/folder structure should look like for now:
```
project_name
  |
  |--static - CSS, JS, images, videos go here
  |
  |--templates - HTML files go here
  |
  |--Pipfile
  |
  |--Pipfile.lock
  |
  ---server.py
```
From the platform, here are some examples of linking files:
```html
<!-- based on the folder structure on the right -->
<!-- linking a css style sheet -->
<link rel="stylesheet" type="text/css" href="{{ url_for('static', filename='my_style.css') }}">
<!-- linking a javascript file -->
<script type="text/javascript" src="{{ url_for('static', filename='my_script.js') }}"></script>
<!-- linking an image -->
<img src="{{ url_for('static', filename='my_img.png') }}">
```
NOTE: Sometimes the server won't have the latest files.  You should try a hard refresh (Cmd+Shift+R for Mac, Ctrl+Shift+R for Windows).