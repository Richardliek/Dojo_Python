from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.models import player

class Team:
    db_name = 'football_schema' # Make use of class variable to hold schema name
    
    # Model for the team - notice the names of the fields match those in the DB
    def __init__(self,data):
        self.id = data['id']
        self.city = data['city']
        self.name = data['name']
        self.stadium_name = data['stadium_name']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.players = [] # Placeholder that will hold a LIST of instances of Players
        # Later this week - linking to players

    # We'll need to know how to:
    # CREATE (add) a team - DONE
    # UPDATE (edit) a team - DONE
    # DELETE a team - added Wednesday
    # READ data:
    # - One team without players - was an interim thing
    # - One team with ALL players - done Wednesday
    # - All teams without players - done Monday
    # - Challenge on your own: ALL teams WITH players
    # - Start with players and...
    #     - Grab one player without team info - done Wednesday
    #     - Grab one player with team info - done Wednesday
    #     - Grab ALL players with their teams - done Wednesday

    # Method to create a new team - notice all the class methods!
    @classmethod
    def create_one(cls, data):
        # This is a prepared statement - notice the %() formats.
        # Use %()s, even for numers - MySQL will convert for you when saved in the database.
        query = "INSERT INTO teams (city, name, stadium_name) VALUES (%(city)s,%(nickname)s,%(stadium_name)s);" # Add query here - test them in MySQL workbench!
        # Need the name of the schema in the connectToMySQL statemet
        return connectToMySQL(cls.db_name).query_db(query, data) # Returns an integer

    @classmethod
    def grab_one_team_without_players(cls, data):
        query = "SELECT * FROM teams WHERE id = %(id)s;"
        results = connectToMySQL(cls.db_name).query_db(query, data) # Returns a list of dictionaries
        if len(results) > 0:
            return cls(results[0])
        else:
            return None

    @classmethod
    def grab_one_team_with_players(cls, data):
        query = "SELECT * FROM teams LEFT JOIN players ON teams.id = players.team_id WHERE teams.id = %(id)s;"
        results = connectToMySQL(cls.db_name).query_db(query, data) # Returns a list of dictionaries
        print(results)
        if len(results) > 0:
            # Create the team
            this_team = cls(results[0])
            # Create players - one at a time
            for this_player in results:
                if this_player['players.id'] != None: # Added due to edge case - NO players on team
                    player_dictionary = {
                        "id": this_player['players.id'],
                        "first_name": this_player['first_name'],
                        "last_name": this_player['last_name'],
                        "number": this_player['number'],
                        "position": this_player['position'],
                        "created_at": this_player['players.created_at'],
                        "updated_at": this_player['players.updated_at'],
                    }
                    player_instance = player.Player(player_dictionary) # Create instance of Player class
                    this_team.players.append(player_instance) # Links a player to this team
            return this_team
        else: # None found
            return []

    # BONUS VIDEO: Starting with teams and then connecting ALL players to their respective teams instead of only one team with their players
    @classmethod
    def grab_all_teams_with_players(cls):
        query = "SELECT * FROM teams LEFT JOIN players ON teams.id = players.team_id;"
        results = connectToMySQL(cls.db_name).query_db(query)
        print(results)
        list_of_teams = []
        if len(results) < 1: # Database is empty - nothing to look at
            return []
        current_team_id = None # Start with an ID that shouldn't exist
        for k in range(len(results)): # Loop through the list of dictionaries - each one has a team/player combo
            current_row = results[k] # Current dictionary
            if current_row['id'] != current_team_id: # New team
                # If past the first row, that means a team was created beforehand, so add it to the list of teams made
                if k > 0:
                    list_of_teams.append(this_team)
                # Now create a new team
                this_team = cls(results[k]) # Create instance of Team class for the new team
                current_team_id = current_row['id'] # Set team ID we're looking at
            if current_row['players.id'] != None: # Added due to edge case - NO players on team
                # Look at the player in question
                player_dictionary = {
                    "id": results[k]['players.id'], # Could've just used current_row instead of results[k] - both work
                    "first_name": results[k]['first_name'],
                    "last_name": results[k]['last_name'],
                    "number": results[k]['number'],
                    "position": results[k]['position'],
                    "created_at": results[k]['players.created_at'],
                    "updated_at": results[k]['players.updated_at'],
                }
                player_instance = player.Player(player_dictionary) # Create instance of Player class
                this_team.players.append(player_instance) # Link the Player to the current Team
            if k == len(results) - 1: # If we're at the end of the list of rows
                # Add this final team
                list_of_teams.append(this_team)
        return list_of_teams

    @classmethod
    def edit_one_team(cls,data):
        query = "UPDATE teams SET city = %(city)s, name = %(nickname)s, stadium_name = %(stadium_name)s WHERE id = %(id)s;"
        return connectToMySQL(cls.db_name).query_db(query, data)

    @classmethod
    def grab_all_teams(cls): # All teams without players
        query = "SELECT * FROM teams;"
        results = connectToMySQL(cls.db_name).query_db(query) # Returns a list of dictionaries
        # print(results)
        all_teams = [] # List of Teams
        for this_team in results:
            team_class_instance = cls(this_team)
            all_teams.append(team_class_instance)
        return all_teams

    @classmethod
    def delete_team(cls, data):
        query = "DELETE FROM teams WHERE id = %(id)s;"
        return connectToMySQL(cls.db_name).query_db(query, data)