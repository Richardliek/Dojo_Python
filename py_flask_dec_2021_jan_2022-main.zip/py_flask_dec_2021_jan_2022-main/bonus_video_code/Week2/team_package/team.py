class Team:
    def __init__(self, city, nickname, sport):
        self.city = city
        self.nickname = nickname
        self.sport = sport