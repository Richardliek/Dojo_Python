class Genre: # Define a genre of music, e.g. rock, pop, rap
    def __init__(self, name): # Method used to create an instance of this class
        self.name = name # Attributes named name and artists
        self.artists = [] # Empty list that will hold instances of Artists (note the capitalization)
        # Name of genre, artists, BPM, decades
    
    # Instance method - notice the "self" as the first parameter
    def add_artist(self, new_artist):
        self.artists.append(new_artist) # new_artist is an instance of the Artist class
        return self # Allows for chaining