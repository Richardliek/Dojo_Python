# import artist # Run the entire artist.py file
from artist import Artist
from song import Song
from genre import Genre
from team_package import team

# madonna = artist.Artist("Madonna Ciccone","United States",57) # If you use "import module_name"
madonna = Artist("Madonna Ciccone","United States",57) # If you use "from module_name import variable/function/class"
print(madonna.name)

material_girl = Song("Material Girl",210,"...")
holiday = Song("Holiday",210,"...")

madonna.add_song(material_girl).add_song(holiday)

# Loop through all the songs for Madonna
for song in madonna.songs:
    print(song.title)

# List of built-in modules (Python 3.10):
# https://docs.python.org/3/py-modindex.html

# Testing built-in module
from datetime import datetime

print(datetime.today())

# Defining a team from the team_package folder (or package)
seahawks = team.Team("Seattle","Seahawks","Football")
print(f"{seahawks.city} {seahawks.nickname}")