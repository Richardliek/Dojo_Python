class Song:
    def __init__(self, title, length, lyrics):
        self.title = title
        self.length_of_time = length # In seconds
        self.lyrics = lyrics
        # Title, length of song, lyrics, artist, instruments

    def change_lyrics(self, new_lyrics):
        self.lyrics = new_lyrics
        return self

    def change_time(self,new_time):
        self.length_of_time = new_time
        return self

    @staticmethod
    def is_song_long_enough(seconds):
        if seconds > 90:
            return True
        else:
            return False