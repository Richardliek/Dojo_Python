class Artist:
    number_of_artists = 0 # Class variable
    all_artists = [] # Class variable that will hold instances of the Artist class

    def __init__(self, name, origin, age):
        self.name = name
        self.starting_point = origin
        self.age = age
        self.songs = []
        Artist.number_of_artists += 1 # To access a class variable from an instance method, you type
        # ClassName.class_variable
        Artist.all_artists.append(self) # Adding an instance of the Artist class to the list

    # Instance method
    def add_song(self, new_song):
        self.songs.append(new_song) # new_song is an instance of the Song class
        return self # Allows for chaining
    
    # Method to show the names of all the artists
    @classmethod
    def show_all_artists(cls):
        for artist in cls.all_artists: # To access a class variable in a class method, do cls.class_variable
            print(artist.name)
    # Name, songs, where they started (or born), age