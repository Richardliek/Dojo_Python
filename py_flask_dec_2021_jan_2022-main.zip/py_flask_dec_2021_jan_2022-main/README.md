# Welcome to the Python-Flask stack for December 2021-January 2022!

Here you will find lecture code and notes throughout the 8 weeks of the stack.  Keep an eye on this repository as we progress through the material.  Have a good time learning Python, MySQL and Flask!