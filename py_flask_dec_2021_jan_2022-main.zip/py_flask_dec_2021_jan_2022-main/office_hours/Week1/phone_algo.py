"""
From CodeWars: https://www.codewars.com/kata/54a2e93b22d236498400134b/train/python
Prior to having fancy iPhones, teenagers would wear out their thumbs sending SMS messages 
on candybar-shaped feature phones with 3x4 numeric keypads.

------- ------- -------
|     | | ABC | | DEF |
|  1  | |  2  | |  3  |
------- ------- -------
------- ------- -------
| GHI | | JKL | | MNO |
|  4  | |  5  | |  6  |
------- ------- -------
------- ------- -------
|PQRS | | TUV | | WXYZ|
|  7  | |  8  | |  9  |
------- ------- -------
------- ------- -------
|     | |space| |     |
|  *  | |  0  | |  #  |
------- ------- -------

Prior to the development of T9 (predictive text entry) systems, the method to type words was 
called "multi-tap" and involved pressing a button repeatedly to cycle through the possible values.

For example, to type a letter "R" you would press the 7 key three times (as the screen display 
for the current character cycles through P->Q->R->S->7). A character is "locked in" once the 
user presses a different key or pauses for a short period of time (thus, no extra button presses 
are required beyond what is needed for each letter individually). The zero key handles spaces, 
with one press of the key producing a space and two presses producing a zero.

In order to send the message "WHERE DO U WANT 2 MEET L8R" a teen would have to actually do 47 button presses. 
No wonder they abbreviated.

For this assignment, write a module that can calculate the amount of button presses required for any phrase. 
Punctuation can be ignored for this exercise. Likewise, you can assume the phone doesn't distinguish between 
upper/lowercase characters (but you should allow your module to accept input in either for convenience).
"""

def presses(phrase):
    # Dictionary where each key is a digit in the keypad
    """
    IMPORTANT CHANGE that screwed us up in office hour: everything has to be a string
    print('1' in [1]) # Prints False
    print('1' in ['1']) # Prints True
    So in this code: "if val in list", it checks value AND type (number vs. string) - it
    gave us False because '1' is not the same as 1 because of different data types.
    """
    keypad_dictionary = {
        '1': ['1'],
        '2': ['A','B','C','2'],
        '3': ['D','E','F','3'],
        '4': ['G','H','I','4'],
        '5': ['J','K','L','5'],
        '6': ['M','N','O','6'],
        '7': ['P','Q','R','S','7'],
        '8': ['T','U','V','8'],
        '9': ['W','X','Y','Z','9'],
        '0': [' ','0'],
        '#': ['#'], # Added
        '*': ['*'], # Added
    }
    total_keypresses = 0 # Keeps track of the total number of presses
    # Look at each character in the string
    for k in range(len(phrase)):
        current_char = phrase[k] # Gets the current letter in the string
        # If it is a letter, convert it to upper case....
        if current_char.isalpha():
            current_char = current_char.upper() # Convert to upper case
        # ... otherwise, leave it alone (no else block needed)
        # Loop through each key
        for curr_key in keypad_dictionary:
            # Grabbing the list linked to this current key
            curr_list = keypad_dictionary[curr_key]
            # If value found in the list...
            if current_char in curr_list:
                # Locate its index
                index = curr_list.index(current_char)
                # Then get and add the number of keypresses
                num_keypresses = index + 1
                total_keypresses += num_keypresses
    return total_keypresses