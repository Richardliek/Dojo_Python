class User: # here's what we have so far
    def __init__(self, name, email):
        self.name = name
        self.email = email
        self.account_balance = 0

    def deposit(self, amount): 
        # Tip #1A: Know your inputs - does your function/method need values?
        # Know what data types your inputs will be!

        # Tip #2: What is the function supposed to accomplish?
        # In this case, we take the amount given to the method and add it to our balance

        # Tip #3A: What steps would you take in a real-life setting - so no code initially - to tackle
        # the problem?
        # Tip #3B: Once you figure out how to solve the problem without a computer, now try to figure 
        # out how the computer would solve the problem.  So would you need new variables to hold values like 
        # a sum, a minimum, a maximum, etc.  Write out in terms of "pseudocode" how the computer would solve
        # the given problem?

        """ Example of pseudocode: Find the biggest value in a list
        Watch out for edge cases!  Examples: empty list, one item only, etc.
        Start off with the first value
        for each value in the list:
            if the current value is bigger than the biggest value found so far:
                make that the new maximum
        """
        # Tip #4: Write out test cases!  Make sure it works in all cases - including those nasty "edge cases"
        self.account_balance += amount
        # Tip #5: If you find that the code is not giving you the results you expect, use some T-diagrams
        # and/or add some print statements.

        # Tip #1B: What are your outputs
        return self # To allow for chaining

    def withdraw(self, amount):
        """
        Sometimes people will define the variable that they will eventually return and then add the "return"
        statement at the end so that they don't forget.
        x = 0
        return x
        """
        # Edge case: there is not enough funds in the account to allow the withdrawal
        if self.account_balance - amount >= 0:
            self.account_balance -= amount
        else:
            print("Nonsufficient funds")
        return self

    def transfer_money(self, other_user, amount):
        # Another handy tip: know what data types your inputs will be
        # other_user - instance of the User class
        # amount - float
        
        # Random tip: You can always call on methods within your class: self.withdraw(amount)

        # If we have enough money....
        if self.account_balance - amount >= 0:
            self.account_balance -= amount # Remove the money from our account
            other_user.account_balance += amount # Add the money to the other user's account
            # other_user.deposit(amount) # Alternate way to add to other user's account
        return self


adrian = User("Adrian","adrian@mail.org")
jane = User("Jane","jane@mail.com")
adrian.deposit(1000).deposit(500)
jane.deposit(500).withdraw(700) # Can't withdraw 700
adrian.transfer_money(jane,300)
print(adrian.account_balance) # Should be 1200
print(jane.account_balance) # Should be 500 + 300 = 800