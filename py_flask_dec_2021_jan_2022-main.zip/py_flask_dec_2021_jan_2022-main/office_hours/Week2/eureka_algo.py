"""
https://www.codewars.com/kata/5626b561280a42ecc50000d1/train/python

The number 89 is the first integer with more than one digit that fulfills the property partially 
introduced in the title of this kata. What's the use of saying "Eureka"? Because this sum gives the same number.

In effect: 89 = 8^1 + 9^2

The next number in having this property is 135.

See this property again: 135 = 1^1 + 3^2 + 5^3

We need a function to collect these numbers, that may receive two integers a, b that defines the 
range [a, b] (inclusive) and outputs a list of the sorted numbers in the range that fulfills 
the property described above.

Let's see some cases:
sum_dig_pow(1, 10) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
sum_dig_pow(1, 100) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 89]

If there are no numbers of this kind in the range [a, b] the function should 
output an empty list.

sum_dig_pow(90, 100) == []

"""
def sum_dig_pow(a, b): # range(a, b + 1) will be studied by the function
    # Input: two numbers representing a range
    # Output: a list of numbers satisfying the given property
    
    # Check each value in this range [a, b]
    """
    for each value in the range:
        1. Take the current value and split it by its digits
           "89" -> "8","9".
        2. Perform the calculation itself: 8^1 + 9^2 for 89, e.g.
           If the property is satisfied - so if the sum equals the current value,
           we will append this number to the list.
    Once we're done, we'll return the list.
    """
    new_list = []
    for val in range(a,b+1):
        val_str = str(val) # Convert the current number into a string "89"
        # print(val_str + ":")
        current_number_of_digits = 1 # 1 = 1st digit, 2 = 2nd digit, etc.
        digit_sum = 0 # Hold a sum of all the digits (after being raised to the proper power)
        # Loop through each digit
        for current_digit in val_str:
            digit_sum += int(current_digit) ** current_number_of_digits # 5 ** 2 = 5^2 = 25
            current_number_of_digits += 1
        # Check to see if the sum is equal to the value we're examining right now
        if digit_sum == val:
            new_list.append(val)
    return new_list

# print(sum_dig_pow(1,10))
# print(sum_dig_pow(1,100))
print(sum_dig_pow(1,200))
# print(sum_dig_pow(90,100))