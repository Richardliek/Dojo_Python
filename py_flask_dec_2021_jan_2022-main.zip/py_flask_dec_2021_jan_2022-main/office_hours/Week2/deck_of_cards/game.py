from classes.deck import Deck

bicycle = Deck() 

# bicycle.show_cards()
# print("-----------------------")
bicycle.shuffle() # Shuffle the deck

"""
Game: Two players will draw cards, taking turns.  Each player will receive one card at a time.
A player may choose to draw a card, or stop, and force the other player to keep drawing.
GOAL: The player with the biggest score wins.
CATCH: If you draw an Ace, you lose.
If one player is left, then the other player must keep drawing until beating the other player's score - thus winning, OR
an Ace is drawn - thus losing.
"""

is_game_active = True
player_1_cards = [] # Empty list, each item will be an instance of the Card class
player_2_cards = []
player_1_sum = 0 # Cumulative score
player_2_sum = 0
player_1_wants_to_play = "A" # Placeholder - must be nonempty and cannot start with Y or N
player_2_wants_to_play = "A"

while is_game_active == True:
    # Ask until player 1 enters "Y" or "N" - as long as player 2 hasn't stopped
    while player_2_wants_to_play[0].upper() != "N" and player_1_wants_to_play[0].upper() != "Y" \
        and player_1_wants_to_play[0].upper() != "N":
        player_1_wants_to_play = input("Player 1: Do you want another card? (Y/N): ")
    # Give player 1 a card - if they choose to OR forcibly give them a card if the other player stops
    if player_1_wants_to_play == "Y" or player_2_wants_to_play == "N":
        # Deal the card and add it to the player's hand
        new_card = bicycle.deal_card()
        player_1_cards.append(new_card)
        player_1_sum += new_card.point_val
        print("Player 1 receives:")
        new_card.card_info()
        if new_card.string_val == "Ace": # If an ace is drawn, player 1 loses
            print("Player 1 loses!  So player 2 wins!")
            is_game_active = False
            break
        # Check player 1's cards and see if sum > player 2's cards if player 2 stopped
        if player_2_wants_to_play == "N" and player_1_sum > player_2_sum:
            print(f"Player 1 wins with a score of {player_1_sum} over Player 2's {player_2_sum}")
            is_game_active = False
            break
        player_1_wants_to_play = "A" # Reset this variable so we can ask player 1 again

    # Same idea for player 2, except the other way around

    while player_1_wants_to_play[0].upper() != "N" and player_2_wants_to_play[0].upper() != "Y" \
        and player_2_wants_to_play[0].upper() != "N":
        player_2_wants_to_play = input("Player 2: Do you want another card? (Y/N): ")
    # Give player one a card - if they want
    if player_2_wants_to_play == "Y" or player_1_wants_to_play == "N":
        new_card = bicycle.deal_card()
        player_2_cards.append(new_card)
        player_2_sum += new_card.point_val
        print("Player 2 receives:")
        new_card.card_info()
        if new_card.string_val == "Ace":
            print("Player 2 loses!  So player 1 wins!")
            is_game_active = False
            break
        if player_1_wants_to_play == "N" and player_2_sum > player_1_sum:
            print(f"Player 2 wins with a score of {player_2_sum} over Player 1's {player_1_sum}")
            is_game_active = False
            break
        player_2_wants_to_play = "A" # Reset this variable so we can ask the player again
    print(f"Current scores - Player 1: {player_1_sum}; Player 2: {player_2_sum}")

# Show the cards for each player
print("Player 1:")
for card in player_1_cards:
    card.card_info()

print("Player 2:")
for card in player_2_cards:
    card.card_info()
