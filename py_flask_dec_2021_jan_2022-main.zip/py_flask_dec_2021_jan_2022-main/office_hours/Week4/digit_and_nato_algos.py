""" From CodeWars:
Given a number represented as a list of digits, for example [3, 4, 8] for 348, add one to the value and return a
new list representing the new value.  In this case, [3, 4, 9] for 349.
"""

def up_array(arr):
    print(arr)
    if len(arr) == 0: # Edge case - list is empty
        return None
    # If any number is more than 1 digit or is negative, return None
    # [2, 10] or [4, -8]
    original_num_str = ""
    for val in arr:
        # If invalid entry, return None
        if val < 0 or val >= 10:
            return None
        else:
            original_num_str += str(val)
    new_num_str = str(int(original_num_str) + 1) # Add one to value
    new_num_list = list(new_num_str) # Convert string to a list
    for i in range(len(new_num_list)): # Convert each item in list from a string to a number
        new_num_list[i] = int(new_num_list[i])
    return new_num_list

print(up_array([3,8,4]))
print(up_array([3,-8,3]))
print(up_array([9,9,9]))

"""
Mash the numbers together into a string.  So [2, 5] -> "25".
Convert it to an integer. "25" -> 25
Add one. 25 + 1 -> 26
Convert back to a string. 26 -> "26"
Split this into a list, where each digit would be its own entry.
"26" -> ["2","6"]
Convert each item into an integer. ["2","6"] -> [2, 6]
"""

"""
https://www.codewars.com/kata/586538146b56991861000293/train/python

Task:
You'll have to translate a string to Pilot's alphabet (NATO phonetic alphabet).

Input:
If, you can read?

Output:
India Foxtrot , Yankee Oscar Uniform Charlie Alfa November Romeo Echo Alfa Delta ?

Note:

There are preloaded dictionary you can use, named NATO
The set of used punctuation is ,.!?.
Punctuation should be kept in your return string, but spaces should not.
Xray should not have a dash within.
Every word and punctuation mark should be seperated by a space ' '.
There should be no trailing whitespace
"""
def to_nato(words):
    NATO = {'A': 'Alfa', 'B': 'Bravo', 'C': 'Charlie', 'D': 'Delta', 'E': 'Echo', 'F': 'Foxtrot', 'G': 'Golf', 'H': 'Hotel', 'I': 'India', 'J': 'Juliett', 'K': 'Kilo', 'L': 'Lima', 'M': 'Mike', 'N': 'November', 'O': 'Oscar', 'P': 'Papa', 'Q': 'Quebec', 'R': 'Romeo', 'S': 'Sierra', 'T': 'Tango', 'U': 'Uniform', 'V': 'Victor', 'W': 'Whiskey', 'X': 'Xray', 'Y': 'Yankee', 'Z': 'Zulu'}
    converted_string = ""
    for i in range(len(words)):
        current_character = words[i].upper()
        if current_character in NATO:
            converted_string += NATO[current_character] + " "
        elif current_character != " ":
            converted_string += current_character + " "
    converted_string = converted_string.strip() # Trim excess whitespaces
    return converted_string


"""
test.describe("Basic Tests")
test.assert_equals(to_nato('If you can read'), "India Foxtrot Yankee Oscar Uniform Charlie Alfa November Romeo Echo Alfa Delta")
test.assert_equals(to_nato('Did not see that coming'), "Delta India Delta November Oscar Tango Sierra Echo Echo Tango Hotel Alfa Tango Charlie Oscar Mike India November Golf")
test.assert_equals(to_nato('.d?d!'),'. Delta ? Delta !')
"""