from flask import Flask  # Import Flask to allow us to create our app
app = Flask(__name__)    # Create a new instance of the Flask class called "app"

@app.route('/')          # The "@" decorator associates this route with the function immediately following
def hello_world():
    return 'Hello World!'  # Return the string 'Hello World!' as a response

@app.route('/hi')
def hi_route():
    return "Hi there!"

@app.route('/<int:count>') # int: is used to convert a variable to an integer
def count_function(count): # Count is a non-negative integer
    # /10 -> "1, 2, 3, 4, 5, 6, 7, 8, 9, 10"
    # print(type(count)) # Now int
    number_string = "1"
    for i in range(2,count+1):
        number_string += ", " + str(i)
    return number_string

# Goal: Display, Hi, my name is ____ and my favorite number is ___.
@app.route('/hello/<name>/<int:number>')
def hi_name_number(name,number):
    return f"Hi, my name is {name} and my favorite number is {number}."

# Display the same message that many times
@app.route('/hello/again/<name>/<int:number>')
def hi_repeat(name,number):
    output_str = ""
    for i in range(number):
        # You can add HTML inside your string
        output_str += f"<p>Hi, my name is {name} and my favorite number is {number}.</p>"
    return output_str

if __name__=="__main__":   # Ensure this file is being run directly and not from a different module    
    app.run(debug=True)    # Run the app in debug mode.