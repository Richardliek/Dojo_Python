# Review of f strings
x = 10
print(f"I have {x} dollars")
# return redirect(f"/books/{id}")
print("I have " + str(x) + " dollars")

# Review of OOP

# Gadgets - stores
class Gadget:
    total_gadgets = 0 # Class variable
    most_expensive_gadget = None # Placeholder

    def __init__(self,id,price,brand_name,hardware):
        self.id = id
        self.price = price
        self.brand_name = brand_name
        self.hardware = hardware
        Gadget.total_gadgets += 1
        if Gadget.most_expensive_gadget == None or self.price > Gadget.most_expensive_gadget.price:
            Gadget.most_expensive_gadget = self

    @classmethod
    def print_most_expensive_gadget_info(cls):
        if cls.most_expensive_gadget != None:
            print(f"ID: {cls.most_expensive_gadget.id}")
            print(f"Price: {cls.most_expensive_gadget.price}")
            print(f"Brand Name: {cls.most_expensive_gadget.brand_name}")
            print(f"Hardware: {cls.most_expensive_gadget.hardware}")
        else:
            print("No gadgets defined")

    @staticmethod
    def can_afford_item(your_money,gadget_price):
        if your_money >= gadget_price:
            return True
        else:
            return False

class Store:
    def __init__(self, id, name):
        self.id = id
        self.name = name
        self.gadgets_sold = []

    def add_gadget(self, new_gadget):
        self.gadgets_sold.append(new_gadget)

Gadget.print_most_expensive_gadget_info()
my_tablet = Gadget(1, 2299.99,"Apple","tablet")
my_computer = Gadget(2, 1999.99,"HP","computer")
# print(Gadget.most_expensive_gadget.price)
Gadget.print_most_expensive_gadget_info()

print(Gadget.can_afford_item(500,1000))

awesome_store = Store(1,"Best Buy")
another_store = Store(2,"Radio Shack")

awesome_store.add_gadget(my_tablet)

class Gadget2: # Defining this by passing in data dictionaries - you'll do this a LOT when you interact with your databases
    def __init__(self,data): # data will be a dictionary
        self.id = data["id"]
        self.price = data["price"]
        self.brand_name = data["brand_name"]
        self.hardware = data["hardware"]
        Gadget.total_gadgets += 1
        if Gadget.most_expensive_gadget == None or self.price > Gadget.most_expensive_gadget.price:
            Gadget.most_expensive_gadget = self

my_list = [
    {
        "id": 1, 
        "price": 299.99, 
        "brand_name": "Apple", 
        "hardware": "tablet"
    },
    {
        "id": 2, 
        "price": 1999.99, 
        "brand_name": "HP", 
        "hardware": "computer"
    },
]

print(my_list[0])

tablet_v2 = Gadget2(my_list[0])
computer_v2 = Gadget2(my_list[1])
list_of_gadget_classes = [tablet_v2, computer_v2]
print(tablet_v2.id)

# Loop through a list of dictionaries
for this_dictionary in my_list:
    print(this_dictionary)
    print(this_dictionary["id"])

# Loop through a list of classes
for this_gadget in list_of_gadget_classes:
    print(this_gadget.id)
    print(this_gadget.price)